/** Combined server entry point: original SUDO bot + public Telegram installer. */
import './index.js';
import telegramConfig from './config.telegram.js';
import { startTelegramInstall } from './telegram_install.js';

startTelegramInstall({
  token: process.env.TELEGRAM_BOT_TOKEN || telegramConfig.token,
  allowedIds: telegramConfig.allowedIds,
});

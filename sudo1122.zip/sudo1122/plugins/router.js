/* نقطة دخول الأوامر — كل الأوامر الفعلية موجودة في مجلد commands */
import { route, loadCommands, getCommands } from '../lib/router.js';

if (!getCommands().length) await loadCommands();

export default async function before(m, ctx, bot) {
  return route(m, ctx, bot);
}

/**
 * Public Telegram installer for SUDO-BOT.
 * Each customer gets an isolated copy and an independent Node process.
 * Original SUDO source files are copied unchanged into each instance.
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { Telegraf, Markup } from 'telegraf';
import telegramConfig from './config.telegram.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(ROOT, 'data');
const INSTANCES_DIR = path.join(ROOT, 'instances');
const OWNERS_FILE = path.join(DATA_DIR, 'telegram-owners.json');
const sessions = new Map();
const workers = new Map();
const cooldowns = new Map();
const dailyAttempts = new Map();
const intentionalStops = new Set();
const restartHistory = new Map();

function readOwners() {
  try {
    const value = JSON.parse(fs.readFileSync(OWNERS_FILE, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch { return {}; }
}
const owners = readOwners();

function saveOwners() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temp = `${OWNERS_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(owners, null, 2), { mode: 0o600 });
  fs.renameSync(temp, OWNERS_FILE);
}

function privateOnly(ctx) {
  return ctx.chat?.type === 'private' && Boolean(ctx.from?.id);
}

function cleanPhone(raw) {
  return String(raw || '').replace(/[+\s\-()]/g, '').replace(/^00/, '');
}

function validPhone(phone) {
  return /^\d{8,15}$/.test(phone);
}

function instancePath(userId) {
  // Telegram IDs are numeric; never use arbitrary user text as a filesystem path.
  return path.join(INSTANCES_DIR, `user-${String(userId).replace(/\D/g, '')}`);
}

function prepareInstance(userId) {
  const dest = instancePath(userId);
  fs.mkdirSync(INSTANCES_DIR, { recursive: true });
  const excluded = new Set([
    'node_modules', 'instances', 'session', 'data', 'sub', '.git',
    'server.js', 'telegram_install.js', 'config.telegram.js', '.env', '.env.example'
  ]);
  fs.mkdirSync(dest, { recursive: true, mode: 0o700 });
  // Sync the original application files on every start, but never overwrite
  // a customer's private data or WhatsApp session directories.
  for (const entry of fs.readdirSync(ROOT)) {
    if (excluded.has(entry)) continue;
    fs.cpSync(path.join(ROOT, entry), path.join(dest, entry), { recursive: true, force: true });
  }
  fs.mkdirSync(path.join(dest, 'data'), { recursive: true, mode: 0o700 });
  fs.mkdirSync(path.join(dest, 'session'), { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dest, 0o700); } catch {}
  return dest;
}

function sendPairCode(bot, userId, phone, code) {
  const message =
    `🔐 كود ربط واتساب جاهز\n\n` +
    `📱 الرقم: ${phone}\n` +
    `🔑 الكود: ${code}\n\n` +
    `طريقة الربط:\n` +
    `1. افتح واتساب على هاتفك\n` +
    `2. الإعدادات ← الأجهزة المرتبطة\n` +
    `3. ربط جهاز ← الربط برقم الهاتف\n` +
    `4. أدخل الكود أعلاه\n\n` +
    `لا تشارك هذا الكود مع أي شخص.`;
  return bot.telegram.sendMessage(userId, message, {
    reply_markup: {
      inline_keyboard: [[
        {
          text: '📋 نسخ الكود',
          copy_text: { text: String(code) }
        }
      ]]
    }
  });
}

function stopWorker(userId) {
  const id = String(userId);
  const worker = workers.get(id);
  intentionalStops.add(id);
  if (!worker) return Promise.resolve();
  if (worker.pairTimer) clearTimeout(worker.pairTimer);
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      workers.delete(id);
      resolve();
    };
    worker.child.once('exit', done);
    try { worker.child.kill('SIGTERM'); } catch { done(); }
    const force = setTimeout(() => {
      try { worker.child.kill('SIGKILL'); } catch {}
      done();
    }, 4000);
    force.unref?.();
  });
}

function removeInstanceFiles(userId) {
  fs.rmSync(instancePath(userId), { recursive: true, force: true });
}

function startWorker(bot, userId, record, { restoring = false } = {}) {
  const id = String(userId);
  if (workers.has(id)) return workers.get(id);
  intentionalStops.delete(id);
  const cwd = prepareInstance(id);
  const child = spawn(process.execPath, ['index.js'], {
    cwd,
    env: { ...process.env, BOT_NUMBER: record.phone },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  const worker = { child, pairTimer: null, ready: false, phone: record.phone };
  workers.set(id, worker);
  record.status = restoring ? (record.status || 'starting') : 'starting';
  record.instanceDir = path.relative(ROOT, cwd);
  saveOwners();

  const parseLine = async (rawLine) => {
    const line = String(rawLine).replace(/\x1B\[[0-?]*[ -/]*[@-~]/g, '');
    console.log(`[SUDO instance ${id}] ${line}`);
    const pair = line.match(/كود الربط:\s*([A-Z0-9-]{6,})/i);
    if (pair && !worker.ready && owners[id]) {
      owners[id].status = 'pairing';
      saveOwners();
      try { await sendPairCode(bot, id, record.phone, pair[1]); }
      catch (error) { console.error(`[Telegram delivery ${id}]`, error?.message || error); }
    }
    if (/متصل.*الحماية تعمل/.test(line) && !worker.ready) {
      worker.ready = true;
      if (worker.pairTimer) clearTimeout(worker.pairTimer);
      if (owners[id]) {
        const wasConnected = owners[id].status === 'connected';
        owners[id].status = 'connected';
        saveOwners();
        sessions.delete(id);
        if (!wasConnected) {
          try { await bot.telegram.sendMessage(id, `✅ تم اتصال نسخة SUDO-BOT الخاصة بك بنجاح.\n📱 ${record.phone}`); } catch {}
        }
      }
    }
  };

  const out = createInterface({ input: child.stdout });
  const err = createInterface({ input: child.stderr });
  out.on('line', (line) => { void parseLine(line); });
  err.on('line', (line) => console.error(`[SUDO instance ${id}] ${line}`));

  if (!restoring || record.status !== 'connected') worker.pairTimer = setTimeout(async () => {
    if (worker.ready || !owners[id] || workers.get(id) !== worker) return;
    try { await bot.telegram.sendMessage(id, '⏰ انتهت مهلة ربط واتساب. أعد المحاولة باستخدام /install أو ألغِ العملية بواسطة /cancel.'); } catch {}
    await stopWorker(id);
    if (owners[id]) {
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }
    sessions.delete(id);
  }, telegramConfig.pairTimeoutMs);
  worker.pairTimer?.unref?.();

  child.on('error', async (error) => {
    console.error(`[SUDO instance ${id}] spawn error:`, error?.message || error);
  });

  child.on('exit', async (code, signal) => {
    if (workers.get(id) === worker) workers.delete(id);
    if (worker.pairTimer) clearTimeout(worker.pairTimer);
    if (intentionalStops.has(id) || !owners[id]) return;

    owners[id].status = 'restarting';
    saveOwners();
    const now = Date.now();
    const history = (restartHistory.get(id) || []).filter((t) => now - t < 10 * 60_000);
    history.push(now);
    restartHistory.set(id, history);
    if (history.length > telegramConfig.restartLimit) {
      owners[id].status = 'stopped';
      saveOwners();
      try { await bot.telegram.sendMessage(id, '⚠️ توقفت نسختك بعد عدة محاولات تشغيل فاشلة. تواصل مع مسؤول السيرفر.'); } catch {}
      return;
    }
    console.warn(`[SUDO instance ${id}] exited (${code ?? signal}); restarting in 5s`);
    const timer = setTimeout(() => {
      if (owners[id] && !workers.has(id)) startWorker(bot, id, owners[id], { restoring: true });
    }, 5000);
    timer.unref?.();
  });

  return worker;
}

function canAttempt(userId) {
  const id = String(userId);
  const now = Date.now();
  if (now - (cooldowns.get(id) || 0) < telegramConfig.cooldownMs) {
    return { ok: false, reason: 'انتظر قليلاً قبل محاولة تنصيب جديدة.' };
  }
  const day = new Date().toISOString().slice(0, 10);
  const old = dailyAttempts.get(id);
  const count = old?.day === day ? old.count : 0;
  if (count >= telegramConfig.maxDailyAttempts) {
    return { ok: false, reason: 'وصلت إلى الحد اليومي لمحاولات التنصيب. حاول غداً.' };
  }
  cooldowns.set(id, now);
  dailyAttempts.set(id, { day, count: count + 1 });
  return { ok: true };
}

export function startTelegramInstall({ token = telegramConfig.token, allowedIds = telegramConfig.allowedIds } = {}) {
  const botToken = String(token || '').trim();
  if (!botToken) {
    console.warn('⚠️ [Telegram] اضبط TELEGRAM_BOT_TOKEN في متغيرات بيئة السيرفر.');
    return null;
  }

  const bot = new Telegraf(botToken);
  const allowSet = new Set((allowedIds || []).map(String).filter(Boolean));

  bot.use(async (ctx, next) => {
    if (!privateOnly(ctx)) {
      if (ctx.chat?.type !== 'private') await ctx.reply('🔒 افتح محادثة خاصة مع البوت لاستعمال التنصيب.');
      return;
    }
    if (allowSet.size && !allowSet.has(String(ctx.from.id))) {
      await ctx.reply('🚫 غير مصرح لك باستخدام هذا البوت.');
      return;
    }
    return next();
  });


  const mainMenu = Markup.inlineKeyboard([
    [
      Markup.button.callback('📲 تنصيب بوت', 'ui:install'),
      Markup.button.callback('🤖 نسختي', 'ui:mybot')
    ],
    [
      Markup.button.callback('📊 حالة الاتصال', 'ui:status'),
      Markup.button.callback('❓ المساعدة', 'ui:help')
    ],
    [Markup.button.callback('🗑️ حذف نسختي', 'ui:remove')]
  ]);

  const backMenu = Markup.inlineKeyboard([
    [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
  ]);

  bot.start(async (ctx) => {
    await ctx.reply(
      '🌌 SUDO-BOT | CONTROL PANEL\n\n' +
      'مرحباً بك في لوحة التحكم الخاصة بك.\n' +
      '━━━━━━━━━━━━━━━━━━\n' +
      '⚡ تنصيب مستقل\n' +
      '🔐 جلسة خاصة بك\n' +
      '🛡️ إدارة ومراقبة النسخة\n' +
      '━━━━━━━━━━━━━━━━━━\n\n' +
      'اختر الخدمة:',
      mainMenu
    );
  });

  bot.action('ui:home', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.editMessageText('🌌 SUDO-BOT | CONTROL PANEL\n\nاختر الخدمة:', mainMenu);
  });

  bot.action('ui:install', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (owners[id]) {
      return ctx.editMessageText('⚠️ لديك نسخة مسجلة بالفعل. افتح قسم نسختي.', backMenu);
    }

    if (sessions.has(id)) {
      return ctx.editMessageText('⏳ لديك عملية جارية بالفعل.', backMenu);
    }

    sessions.set(id, { step: 'await_phone' });

    await ctx.editMessageText(
      '📲 تنصيب نسخة جديدة\n\nأرسل رقم واتساب مع رمز الدولة.\nمثال: 212612345678\n\n⚠️ أرسل رقمك أنت فقط.',
      Markup.inlineKeyboard([
        [Markup.button.callback('❌ إلغاء', 'ui:cancel')],
        [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
      ])
    );
  });

  bot.action(['ui:mybot', 'ui:status'], async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);
    const record = owners[id];

    if (!record) {
      return ctx.editMessageText(
        '🤖 لا توجد لديك نسخة مسجلة حالياً.',
        Markup.inlineKeyboard([
          [Markup.button.callback('📲 تنصيب بوت', 'ui:install')],
          [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
        ])
      );
    }

    const labels = {
      connected: '🟢 متصل',
      pairing: '🟡 في انتظار الربط',
      starting: '🔵 قيد التشغيل',
      restarting: '🟠 إعادة التشغيل',
      stopped: '🔴 متوقف'
    };

    await ctx.editMessageText(
      '🤖 معلومات نسختك\n\n' +
      '📱 الرقم: ' + record.phone + '\n' +
      '🔌 الحالة: ' + (labels[record.status] || record.status || 'غير معروفة') + '\n' +
      '📅 تاريخ التنصيب: ' + (record.createdAt || 'غير معروف'),
      Markup.inlineKeyboard([
        [Markup.button.callback('🔄 تحديث الحالة', 'ui:status')],
        [Markup.button.callback('🗑️ حذف النسخة', 'ui:remove')],
        [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
      ])
    );
  });

  bot.action('ui:help', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.editMessageText(
      '❓ المساعدة\n\n' +
      '📲 تنصيب بوت: إنشاء نسخة واتساب مستقلة.\n' +
      '🤖 نسختي: عرض معلومات نسختك.\n' +
      '🗑️ حذف نسختي: حذف النسخة وجلسة واتساب.\n\n' +
      '🔐 لا تشارك كود الربط مع أي شخص.',
      backMenu
    );
  });

  bot.action('ui:remove', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!owners[id]) {
      return ctx.editMessageText('لا توجد نسخة مسجلة لحذفها.', backMenu);
    }

    await ctx.editMessageText(
      '⚠️ هل أنت متأكد من حذف نسختك؟\nسيتم إيقافها وحذف جلسة واتساب.',
      Markup.inlineKeyboard([
        [Markup.button.callback('✅ نعم، احذفها', 'ui:remove_confirm')],
        [Markup.button.callback('↩️ رجوع', 'ui:mybot')]
      ])
    );
  });

  bot.action('ui:remove_confirm', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!owners[id]) {
      return ctx.editMessageText('لا توجد نسخة مسجلة.', mainMenu);
    }

    sessions.delete(id);
    await stopWorker(id);
    delete owners[id];
    saveOwners();
    removeInstanceFiles(id);

    await ctx.editMessageText('✅ تم حذف نسختك وإنهاء جلسة واتساب.', mainMenu);
  });

  bot.action('ui:cancel', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!sessions.has(id)) {
      return ctx.editMessageText('لا توجد عملية جارية.', mainMenu);
    }

    sessions.delete(id);

    if (owners[id]) {
      await stopWorker(id);
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }

    await ctx.editMessageText('✅ تم إلغاء العملية.', mainMenu);
  });

  async function beginInstall(ctx, rawPhone) {
    const userId = String(ctx.from.id);
    if (sessions.has(userId)) return ctx.reply('لديك عملية تنصيب جارية. أرسل /cancel لإلغائها.');
    if (owners[userId]) return ctx.reply('لديك نسخة مسجلة بالفعل. استعمل /mybot أو /remove.');
    const attempt = canAttempt(userId);
    if (!attempt.ok) return ctx.reply(`⏳ ${attempt.reason}`);

    const phone = cleanPhone(rawPhone);
    if (!validPhone(phone)) return ctx.reply('⚠️ رقم غير صالح. أرسله مع رمز الدولة، من 8 إلى 15 رقماً، وبدون +.');
    if (Object.values(owners).some((item) => item.phone === phone)) {
      return ctx.reply('⚠️ هذا الرقم مرتبط بالفعل بنسخة أخرى على السيرفر.');
    }
    const max = Math.max(1, Number(telegramConfig.maxTotalBots) || 5);
    if (Object.keys(owners).length >= max) return ctx.reply('⚠️ وصل السيرفر إلى الحد الأقصى للنسخ حالياً. حاول لاحقاً.');

    owners[userId] = { phone, status: 'starting', createdAt: new Date().toISOString() };
    saveOwners();
    sessions.set(userId, { step: 'pairing', phone });
    await ctx.reply(`⏳ جاري إنشاء نسخة مستقلة للرقم ${phone}. سيصلك كود الربط هنا.`);
    try {
      startWorker(bot, userId, owners[userId]);
    } catch (error) {
      delete owners[userId];
      sessions.delete(userId);
      saveOwners();
      removeInstanceFiles(userId);
      await ctx.reply(`❌ فشل إنشاء النسخة: ${error?.message || error}`);
    }
  }

  bot.command(['install', 'تنصيب'], async (ctx) => {
    if (sessions.has(String(ctx.from.id))) return ctx.reply('لديك عملية جارية بالفعل. أرسل /cancel.');
    await ctx.reply('📱 أرسل رقم واتساب مع رمز الدولة، بدون +. مثال: 212612345678');
    sessions.set(String(ctx.from.id), { step: 'await_phone' });
  });

  bot.command(['number', 'رقم'], async (ctx) => {
    const raw = ctx.message?.text?.trim().split(/\s+/)[1];
    if (!raw) return ctx.reply('مثال: /number 212612345678');
    sessions.delete(String(ctx.from.id));
    await beginInstall(ctx, raw);
  });

  bot.command(['cancel', 'إلغاء'], async (ctx) => {
    const id = String(ctx.from.id);
    const state = sessions.get(id);
    if (!state) return ctx.reply('لا توجد عملية جارية.');
    sessions.delete(id);
    if (owners[id]) {
      await stopWorker(id);
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }
    await ctx.reply('✅ تم إلغاء العملية.');
  });

  bot.command(['mybot', 'نسختي'], async (ctx) => {
    const id = String(ctx.from.id);
    const record = owners[id];
    if (!record) return ctx.reply('ليس لديك نسخة مسجلة. استعمل /install للبدء.');
    await ctx.reply(`🤖 حالة نسختك\n📱 الرقم: ${record.phone}\n🔌 الحالة: ${record.status || 'غير معروفة'}\n🖥️ لكل مستخدم مجلد وجلسة منفصلان.`);
  });

  bot.command(['remove', 'حذف_نسختي'], async (ctx) => {
    const id = String(ctx.from.id);
    if (!owners[id]) return ctx.reply('لا توجد نسخة مسجلة لحذفها.');
    sessions.delete(id);
    await stopWorker(id);
    delete owners[id];
    saveOwners();
    removeInstanceFiles(id);
    await ctx.reply('✅ تم حذف نسختك وإنهاء جلسة واتساب الخاصة بها.');
  });

  bot.on('text', async (ctx) => {
    const id = String(ctx.from.id);
    const state = sessions.get(id);
    if (!state || state.step !== 'await_phone') return;
    const raw = ctx.message.text.trim();
    if (raw.startsWith('/')) return;
    sessions.delete(id);
    await beginInstall(ctx, raw);
  });

  bot.catch((error) => console.error('❌ [Telegram]', error?.message || error));
  bot.launch({ dropPendingUpdates: true })
    .then(() => console.log('✅ [Telegram] Public installer is running'))
    .catch((error) => console.error('❌ [Telegram] Launch failed:', error?.message || error));

  // Restore every previously registered user's isolated process after restart.
  for (const [userId, record] of Object.entries(owners)) {
    if (!record?.phone) continue;
    try { startWorker(bot, userId, record, { restoring: true }); }
    catch (error) { console.error(`[Restore ${userId}]`, error?.message || error); }
  }

  const shutdown = async () => {
    bot.stop('shutdown');
    await Promise.all([...workers.keys()].map((id) => stopWorker(id)));
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  return bot;
}

export default startTelegramInstall;

SUDO BOT - PELLA AUTO-START PATCH

Upload and extract these files into the SAME ROOT FOLDER as server.js,
telegram_install.js, config.telegram.js and index.js. Replace package.json.

The package now points its main entry to pella-start.js and defines an npm
start script. Procfile is included for hosts that recognize Procfile startup.

The launcher checks that required project files exist and then imports
server.js, which starts the Telegram installer.

Important:
- Keep your existing config.telegram.js and data/session files private.
- Do not upload node_modules; the host should install dependencies from package.json.
- This patch does not include the bot project itself.
- Whether Pella automatically executes package.json's start script depends on
  Pella's runtime configuration. The public Pella site advertises Telegram bot
  file uploads, but does not publish a clear Node.js entrypoint specification.

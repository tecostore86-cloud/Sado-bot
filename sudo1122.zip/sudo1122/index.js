/* ═══════════════════════════════════════════
   SUDO ᴮᵒᵗ — بوت حماية المجموعات
   التشغيل: npm start ← أدخل رقم البوت ← خذ كود الربط
   ═══════════════════════════════════════════ */
import fs from 'fs';
import readline from 'readline';
import { Client } from './lib/meowsab/index.mjs';
import config from './config.js';
import { allDevs, state, num } from './lib/utils.js';
import { attach } from './lib/guard.js';
import { loadCommands } from './lib/router.js';

const SESSION = './session';
const NUMBER_FILE = './data/bot-number.txt';

const C = { c: '\x1b[36m', y: '\x1b[33m', g: '\x1b[32m', r: '\x1b[31m', b: '\x1b[1m', x: '\x1b[0m' };

console.log(`${C.c}${C.b}
   ███████╗██╗   ██╗██████╗  ██████╗
   ██╔════╝██║   ██║██╔══██╗██╔═══██╗
   ███████╗██║   ██║██║  ██║██║   ██║
   ╚════██║██║   ██║██║  ██║██║   ██║
   ███████║╚██████╔╝██████╔╝╚██████╔╝
   ╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝   ${C.x}${C.y}ᴮᵒᵗ  •  Group Shield  •  ᴢøx${C.x}
`);

const isRegistered = () => {
  try { return !!JSON.parse(fs.readFileSync(`${SESSION}/creds.json`, 'utf8')).registered; } catch { return false; }
};

function ask(q) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(res => rl.question(q, a => { rl.close(); res(a); }));
}

async function getNumber() {
  let n = num(process.env.BOT_NUMBER || '');
  if (!n && fs.existsSync(NUMBER_FILE)) n = num(fs.readFileSync(NUMBER_FILE, 'utf8'));
  while (!/^\d{8,15}$/.test(n)) {
    n = num(await ask(`${C.y}📱 أدخل رقم البوت مع رمز الدولة (مثال: 212612345678): ${C.x}`));
    if (!/^\d{8,15}$/.test(n)) console.log(`${C.r}❌ رقم غير صحيح، أعد المحاولة.${C.x}`);
  }
  fs.mkdirSync('./data', { recursive: true });
  fs.writeFileSync(NUMBER_FILE, n);
  return n;
}

let pairNumber = isRegistered() ? null : await getNumber();

await loadCommands();

const client = new Client({
  phoneNumber: '',                 // الربط يتم من هنا وليس من المكتبة
  prefix: config.prefix,
  owners: allDevs().map(d => ({ name: d.name, lid: '', jid: `${d.number}@s.whatsapp.net` })),
  settings: { noWelcome: true },   // لا ترحيب: هذا بوت حماية
  commandsPath: './plugins',
  sessionPath: SESSION,
  showLogs: true
});

client.config.info = { ...config.info, images: [] };
client.onCommandAccess(() => false);   // رسائل الرفض يديرها البوت نفسه
state.client = client;

/* مراقبة الاتصال: ربط الحماية + كود الاقتران + تسجيل الخروج */
let lastSock = null;
let groupStatsTimer = null;
let groupStatsBusy = false;

async function updateGroupStats(sock) {
  if (groupStatsBusy || !sock?.groupFetchAllParticipating) return;
  groupStatsBusy = true;

  try {
    const groups = await sock.groupFetchAllParticipating();
    const list = Object.values(groups || {});

    let members = 0;
    let admins = 0;

    for (const group of list) {
      const participants = group.participants || [];
      members += participants.length;
      admins += participants.filter(p =>
        p.admin === 'admin' || p.admin === 'superadmin'
      ).length;
    }

    fs.mkdirSync('./data', { recursive: true });

    const stats = {
      groups: list.length,
      members,
      admins,
      updatedAt: new Date().toISOString()
    };

    const temp = './data/elite-stats.json.tmp';
    fs.writeFileSync(temp, JSON.stringify(stats, null, 2));
    fs.renameSync(temp, './data/elite-stats.json');
  } catch (error) {
    console.error('تعذر تحديث إحصائيات المجموعات:', error.message);
  } finally {
    groupStatsBusy = false;
  }
}
const requested = new WeakSet();

async function requestCode(sock) {
  if (!pairNumber || requested.has(sock) || sock.authState?.creds?.registered) return;
  requested.add(sock);
  try {
    const code = await sock.requestPairingCode(pairNumber);
    const pretty = code?.match(/.{1,4}/g)?.join('-') || code;
    console.log(`\n${C.g}${C.b}╭──────────────────────────────╮`);
    console.log(`│  🔐 كود الربط:  ${pretty}     │`);
    console.log(`╰──────────────────────────────╯${C.x}`);
    console.log(`${C.y}واتساب ← الأجهزة المرتبطة ← ربط جهاز ← الربط برقم الهاتف ← أدخل الكود${C.x}\n`);
  } catch (e) {
    console.log(`${C.r}❌ تعذر طلب كود الربط: ${e.message}${C.x}`);
    requested.delete(sock);
  }
}

function watch(sock) {
  attach(sock);
  if (pairNumber) setTimeout(() => requestCode(sock), 3000);
  sock.ev.on('connection.update', async ({ connection, qr, lastDisconnect }) => {
    if (qr) requestCode(sock);
    if (connection === 'open') {
      pairNumber = null;
      console.log(`${C.g}✅ ${config.info.nameBot} متصل — الحماية تعمل.${C.x}`);
      if (groupStatsTimer) clearInterval(groupStatsTimer);
      updateGroupStats(sock);
      groupStatsTimer = setInterval(() => updateGroupStats(sock), 15 * 60 * 1000);
    }
    if (connection === 'close' && groupStatsTimer) {
      clearInterval(groupStatsTimer);
      groupStatsTimer = null;
    }
    if (connection === 'close' && lastDisconnect?.error?.output?.statusCode === 401) {
      console.log(`${C.r}🚪 تم تسجيل الخروج من واتساب. سيتم حذف الجلسة وطلب رقم جديد...${C.x}`);
      try { fs.rmSync(SESSION, { recursive: true, force: true }); } catch {}
      try { fs.rmSync(NUMBER_FILE, { force: true }); } catch {}
      pairNumber = await getNumber();
      setTimeout(() => client.start(true), 2000);
    }
  });
}

setInterval(() => {
  if (client.sock && client.sock !== lastSock) {
    lastSock = client.sock;
    watch(client.sock);
  }
}, 300);

await client.start();

/* الأخطاء: تُسجّل ولا توقف البوت */
process.on('uncaughtException', (e) => {
  if (String(e?.message).includes('rate-overlimit')) return;
  console.error('Uncaught:', e);
});
process.on('unhandledRejection', (e) => {
  if (String(e?.message || e).includes('rate-overlimit')) return;
  console.error('Unhandled Rejection:', e);
});

/**
 * SUDO-BOT hosted entry point.
 * Loads a local .env file, starts the Telegram installer and HTTP health check,
 * then starts the main WhatsApp bot when BOT_NUMBER or an existing session exists.
 */
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
process.chdir(ROOT);

// Tiny .env loader: no extra package and no terminal setup required.
function loadEnvFile() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const rawLine of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const index = line.indexOf('=');
    if (index < 1) continue;
    const key = line.slice(0, index).trim();
    let value = line.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}
loadEnvFile();

for (const dir of ['data', 'instances']) fs.mkdirSync(path.join(ROOT, dir), { recursive: true });

const port = Number.parseInt(process.env.PORT || '3000', 10);
const healthServer = http.createServer((req, res) => {
  if (req.url === '/' || req.url === '/health') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ status: 'ok', service: 'SUDO-BOT' }));
    return;
  }
  res.writeHead(404, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ error: 'Not found' }));
});
healthServer.listen(port, '0.0.0.0', () => {
  console.log(`✅ SUDO-BOT health endpoint listening on port ${port}`);
});

const telegramConfig = (await import('./config.telegram.js')).default;
const telegramToken = String(process.env.TELEGRAM_BOT_TOKEN || telegramConfig.token || '').trim();
if (telegramToken) {
  const { startTelegramInstall } = await import('./telegram_install.js');
  const bot = startTelegramInstall({
    token: telegramToken,
    allowedIds: telegramConfig.allowedIds,
    eliteIds: telegramConfig.eliteIds,
  });
  if (bot) console.log('✅ SUDO Telegram installer started');
} else {
  console.warn('⚠️ Telegram متوقف: أضف TELEGRAM_BOT_TOKEN داخل ملف .env أو إعدادات الاستضافة.');
}

const sessionCreds = path.join(ROOT, 'session', 'creds.json');
let hasRegisteredSession = false;
try {
  hasRegisteredSession = !!JSON.parse(fs.readFileSync(sessionCreds, 'utf8')).registered;
} catch {}
const botNumber = String(process.env.BOT_NUMBER || '').replace(/\D/g, '');

if (hasRegisteredSession || /^\d{8,15}$/.test(botNumber)) {
  console.log('🚀 Starting main SUDO WhatsApp bot...');
  await import('./index.js');
} else {
  console.warn('⚠️ WhatsApp الرئيسي لم يبدأ بعد: أضف BOT_NUMBER (رقم دولي بدون +) داخل .env أو إعدادات الاستضافة.');
  console.warn('ℹ️ بعد إضافته أعد تشغيل الخدمة؛ سيظهر كود ربط واتساب في سجل التشغيل.');
}

const shutdown = () => {
  healthServer.close();
  process.exit(0);
};
process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);

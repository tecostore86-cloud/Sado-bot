# SUDO-BOT

## Hosted startup

The hosted entry point is `server.js` (`npm start`). It loads `.env` automatically, starts the Telegram installer, exposes `/health` on the hosting `PORT`, and starts the main WhatsApp bot when `BOT_NUMBER` or an existing registered session is present.

### Configure without Terminal

Edit `.env` in the hosting file manager:

```env
BOT_NUMBER=2126XXXXXXXX
TELEGRAM_BOT_TOKEN=YOUR_NEW_BOTFATHER_TOKEN
MAX_SUB_BOTS=5
```

Use a fresh Telegram token from `@BotFather`; do not reuse a token that was included in a shared ZIP. `BOT_NUMBER` is the main WhatsApp number in international digits-only format. The pairing code is printed in the hosting service Logs/Console.

The hosting platform must automatically install dependencies from `package.json` during its build/deploy step. Select Node.js 22 (or 20.19+), use `server.js` as startup file or `npm start` as the start command, and enable persistent storage for `session/`, `data/`, and `instances/`.

See `HOSTING-AR.md` for the setup in Arabic.

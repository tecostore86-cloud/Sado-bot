export default {
  token: process.env.TELEGRAM_BOT_TOKEN || '8313757760:AAEe0w0o5UACTw_q2_FFqD_JooSk9DY2258',
  allowedIds: [],
  eliteIds: ['8914363622'],
  maxTotalBots: Number(process.env.MAX_SUB_BOTS || 5),
  maxDailyAttempts: 3,
  cooldownMs: 30000,
  pairTimeoutMs: 180000,
  restartLimit: 5,
};

import fs from 'node:fs';
import process from 'node:process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const requiredMajor = 20;
const currentMajor = Number(process.versions.node.split('.')[0]);

console.log(`[SUDO] Pella auto-start: Node.js ${process.version}`);

if (!Number.isFinite(currentMajor) || currentMajor < requiredMajor) {
  console.error(`[SUDO] Node.js ${requiredMajor}+ is required; found ${process.version}.`);
  process.exit(1);
}

for (const file of ['server.js', 'telegram_install.js', 'config.telegram.js']) {
  if (!fs.existsSync(path.join(root, file))) {
    console.error(`[SUDO] Required file is missing: ${file}`);
    process.exit(1);
  }
}

process.on('uncaughtException', (error) => {
  console.error('[SUDO] Uncaught exception:', error?.stack || error);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('[SUDO] Unhandled promise rejection:', reason?.stack || reason);
  process.exit(1);
});

try {
  console.log('[SUDO] Loading Telegram installer (server.js)...');
  await import('./server.js');
  console.log('[SUDO] Telegram installer loaded.');
} catch (error) {
  console.error('[SUDO] Startup failed:', error?.stack || error);
  process.exit(1);
}

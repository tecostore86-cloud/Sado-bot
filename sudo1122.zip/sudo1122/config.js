/* ═══════════════════════════════════════════
   SUDO ᴮᵒᵗ — ملف الإعدادات
   عدّل من هنا فقط: المطورين، البادئات، وإعدادات الحماية
   ═══════════════════════════════════════════ */

export default {
  /* معلومات البوت (محفوظة من النسخة الأصلية) */
  info: {
    nameBot: 'SUDO ᴮᵒᵗ',
    nameChannel: 'SUDO ᴮᵒᵗ',
    idChannel: '120363431065008114@newsletter',
    urls: {
      repo: 'https://github.com/deveni0/Pomni-AI',
      api: 'https://emam-api.web.id',
      channel: 'https://whatsapp.com/channel/0029VbDSvFE0LKZ5KhI4L441'
    },
    copyright: {
      pack: 'لا أُقارَن أنا المقياس',
      author: 'tobi'
    }
  },

  /* البادئات المقبولة قبل الأوامر */
  prefix: ['.', '/', '!'],

  /* المطورون الأساسيون (لا يمكن إزالتهم بالأوامر)
     hidden: true  ← له كل الصلاحيات لكنه لا يظهر للناس */
  developers: [
    { name: 'ZØX', number: '212644473603', main: true, hidden: false },
    { name: 'TOBI', number: '212706955693', hidden: false }
  ],

  /* التوقيع الصغير أسفل كل رسالة */
  signature: 'S u D o ~',

  /* المنطقة الزمنية لوقت الإشعارات */
  timezone: 'Africa/Casablanca',

  /* إعدادات الحماية */
  protection: {
    warnLimit: 3,               // عدد الإنذارات قبل الطرد
    botScanInterval: 15000,     // فحص الأجهزة المرتبطة كل 15 ثانية
    botKickDelay: 15000,        // مهلة الترك قبل طرد قائمة المشبوهين
    spam: { count: 7, window: 10000 },     // 7 رسائل خلال 10 ثوانٍ = سبام
    mentionLimit: 10,           // أكثر من 10 منشن في رسالة = منشن جماعي
    crash: { maxText: 6000, maxSize: 45000, maxMarks: 400 },
    takeover: { removeLimit: 3, window: 60000 } // 3 طرد خلال دقيقة من مشرف = محاولة تخريب
  }
};

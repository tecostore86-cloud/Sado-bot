/* قسم الحماية — كل الأوامر للمشرفين */
import db from '../lib/db.js';
import { btn } from '../lib/ui.js';
import * as antibots from '../lib/antibots.js';
import { normalizeText } from '../lib/words.js';
import { targets, partInfo, getMeta } from '../lib/utils.js';

const base = { cat: 'protect', group: true, admin: true };

/* أنظمة التشغيل/الإيقاف البسيطة */
const SYSTEMS = [
  { key: 'anticontact',   name: 'جهات الاتصال', img: 'contact',  on: '📇 جهات الاتصال ممنوعة.. ومرسلها خارجاً.', desc: 'طرد مرسل الجهات' },
  { key: 'anticrash',     name: 'الكراش',       img: 'crash',    on: '⚡ رسائل التخريب تسقط قبل أن تصل.',         desc: 'طرد رسائل التخريب', note: 'نص ضخم • تشكيل مكثّف • رموز خفية • أزرار مفخخة • ملفات بأسماء عملاقة' },
  { key: 'antimention',   name: 'المنشن',       img: 'mention',  on: '📢 لا منشن جماعي إلا للمشرفين.',           desc: 'منع المنشن الجماعي' },
  { key: 'antitoxic',     name: 'السب',         img: 'toxic',    on: '🧼 الكلام المسيء يُمسح.. وصاحبه يُنذر.',    desc: 'حذف السب مع إنذار', note: 'عربي • دارجة • فرنسي • إنجليزي\n> أضف كلماتك: *.اضف كلمة ...*' },
  { key: 'blockMedia',    name: 'الوسائط',      img: 'media',    on: '🖼️ الصور والفيديو والصوت ممنوعة.',          desc: 'حذف الصور والفيديو' },
  { key: 'blockSticker',  name: 'الملصقات',     img: 'sticker',  on: '🏷️ الملصقات ممنوعة هنا.',                   desc: 'حذف الملصقات' },
  { key: 'blockDocument', name: 'الملفات',      img: 'document', on: '📁 الملفات ممنوعة هنا.',                    desc: 'حذف الملفات' }
];

const toggles = [];
for (const s of SYSTEMS) {
  toggles.push({
    ...base, botAdmin: true, names: [`منع ${s.name}`], usage: `منع ${s.name}`, desc: s.desc,
    async run({ g, reply }) {
      g[s.key] = true; db.save();
      await reply({ img: s.img, persona: s.on, title: `منع ${s.name}`, body: `✅ تم التفعيل.${s.note ? `\n${s.note}` : ''}\n> المشرفون مستثنون.` });
    }
  });
  toggles.push({
    ...base, names: [`ايقاف منع ${s.name}`, `سماح ${s.name}`], usage: `ايقاف منع ${s.name}`, desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g[s.key] = false; db.save();
      await reply({ img: s.img, persona: '🛡️ خفّفت القيد بأمر المشرف.', title: `منع ${s.name}`, body: '⛔ تم الإيقاف.' });
    }
  });
}

const on = (v) => (v ? '🟢' : '🔴');
const SPAM_ACTIONS = { 'انذار': 'warn', 'حذف': 'delete', 'طرد': 'kick' };
const SPAM_LABEL = { warn: 'حذف + إنذار', delete: 'حذف رسائله 30 ثانية', kick: 'طرد مباشر' };
const FULL = ['antilink', 'anticontact', 'antispam', 'anticrash', 'antimention', 'antitoxic', 'antitakeover', 'antipromote'];

export default [
  /* لوحة الحماية */
  {
    ...base, names: ['الحماية', 'تفعيل', 'حالة الحماية'], usage: 'الحماية', desc: 'لوحة الحماية',
    async run({ g, reply, prefix }) {
      const bots = { off: '🔴 متوقف', instant: '🟢 طرد فوري', mention: '🟡 بإشارة' }[g.antibots] || '🔴 متوقف';
      const flip = (k, onName, offName, desc) => g[k] ? [offName, `🟢 ← إيقاف`] : [onName, `🔴 ← ${desc}`];
      const r = (rows) => rows.map(([t, d]) => ({ title: t, description: d, id: `${prefix}${t}` }));
      const sections = [
        { title: '🛡️ الحماية الأساسية', rows: r([
          g.antibots === 'off' ? ['طرد البوتات بإشارة', '🔴 ← رصد الأجهزة وقائمة ترك'] : ['ايقاف طرد البوتات', '🟢 ← إيقاف فحص البوتات'],
          ['طرد البوتات', 'طرد فوري للأجهزة'],
          flip('antilink', 'منع الروابط', 'ايقاف منع الروابط', 'حذف الروابط مع إنذار'),
          flip('antispam', 'منع السبام', 'ايقاف منع السبام', 'إيقاف الإغراق'),
          ...SYSTEMS.slice(0, 4).map(s => flip(s.key, `منع ${s.name}`, `ايقاف منع ${s.name}`, s.desc))
        ]) },
        { title: '👑 الإشراف', rows: r([
          flip('antitakeover', 'حماية الادمن', 'ايقاف حماية الادمن', 'منع سحب الإشراف'),
          flip('antipromote', 'منع الترقية', 'ايقاف منع الترقية', 'منع ترقية بلا إذن')
        ]) },
        { title: '🚫 منع الأنواع', rows: r([
          ...SYSTEMS.slice(4).map(s => flip(s.key, `منع ${s.name}`, `ايقاف منع ${s.name}`, s.desc)),
          g.slowmode > 0 ? ['ايقاف الوضع البطيء', '🟢 ← إيقاف'] : ['وضع بطيء 30', '🔴 ← رسالة كل 30 ثانية']
        ]) }
      ];
      await reply({
        img: 'shield',
        persona: '🛡️ هذه دروعي.. اختر ما تشاء.',
        title: 'لوحة الحماية',
        body: [
          `🤖 البوتات: ${bots}`,
          `${on(g.antilink)} الروابط${g.antilink ? (g.linkMode === 'wa' ? ' (واتساب فقط)' : ' (الكل)') : ''}`,
          `${on(g.antispam)} السبام${g.antispam ? ` (${SPAM_LABEL[g.spamAction] || SPAM_LABEL.warn})` : ''}`,
          ...SYSTEMS.map(s => `${on(g[s.key])} ${s.name}`),
          `${on(g.slowmode > 0)} الوضع البطيء${g.slowmode > 0 ? ` (${g.slowmode} ث)` : ''}`,
          `${on(g.antitakeover)} حماية الإشراف`,
          `${on(g.antipromote)} منع الترقية`,
          `${on(g.adminOnly)} وضع الأدمن`,
          `${on(g.notify !== false)} الإشعارات • ${on(g.welcome?.on)} الترحيب • ${on(g.goodbye?.on)} الوداع`,
          `🤝 المتروكون: ${g.spared.length} • 🔇 المكتومون: ${Object.keys(g.mutes || {}).length}`
        ].join('\n'),
        buttons: [
          btn.list('🛡️ الأنظمة', sections),
          btn.quick('🛡️ حماية كاملة', `${prefix}حماية كاملة`),
          btn.quick('⛔ ايقاف الحماية', `${prefix}ايقاف الحماية`)
        ]
      });
    }
  },

  /* ═══ البوتات ═══ */
  {
    ...base, botAdmin: true, names: ['طرد البوتات'], usage: 'طرد البوتات', desc: 'طرد فوري للبوتات',
    async run({ g, chat, reply }) {
      antibots.stop(chat);
      g.antibots = 'instant'; db.save();
      antibots.start(chat);
      await reply({ img: 'bots', persona: '🤖 أي بوت سيُطرد فوراً.', title: 'طرد البوتات', body: '✅ فحص الأجهزة المرتبطة كل 15 ثانية.\n✅ كشف رسائل البوتات (أزرار، معرّفات آلية).\n> المشرفون والمتروكون مستثنون.' });
    }
  },
  {
    ...base, botAdmin: true, names: ['طرد البوتات باشارة', 'طرد البوتات بإشارة'], usage: 'طرد البوتات بإشارة', desc: 'رصد مع قائمة ترك',
    async run({ g, chat, reply }) {
      antibots.stop(chat);
      g.antibots = 'mention'; db.save();
      antibots.start(chat);
      await reply({ img: 'bots', persona: '🤖 سأرصد ثم أنبّه.. وبعدها أنفّذ.', title: 'طرد البوتات بإشارة', body: '✅ كل 15 ثانية: قائمة واحدة بالمشبوهين.\n⏳ بعد 15 ثانية يُطرد من لم يُترك.\n🤝 *.ترك @عضو* أو *.ترك الكل*\n🤖 من يرسل رسالة بوت واضحة يُطرد مباشرة.' });
    }
  },
  {
    ...base, names: ['ايقاف طرد البوتات'], usage: 'ايقاف طرد البوتات', desc: 'إيقاف فحص البوتات',
    async run({ g, chat, reply }) {
      g.antibots = 'off'; db.save();
      antibots.stop(chat);
      await reply({ img: 'bots', persona: '🛡️ أغمضت عين الفحص بأمرك.', title: 'طرد البوتات', body: '⛔ تم إيقاف الفحص.' });
    }
  },
  {
    ...base, hidden: true, names: ['ترك الكل'], usage: 'ترك الكل', desc: 'استثناء كل المشبوهين',
    async run({ chat, reply }) {
      const p = antibots.pending.get(chat);
      if (!p?.list?.length) return reply({ img: 'spare', persona: '🤝 لا أحد ينتظر الحكم الآن.', title: 'ترك الكل', body: 'لا توجد قائمة مشبوهين حالياً.' });
      const list = p.list;
      antibots.spare(chat, list.flatMap(f => [f.tag, f.key]));
      await reply({ img: 'spare', persona: '🤝 عفوت عنهم بأمرك.. ولن أعود إليهم.', title: 'ترك الكل', body: list.map((f, i) => `${i + 1}. @${f.tag}`).join('\n') + '\n\n✅ لن يتم فحصهم مرة أخرى.', mentions: list.map(f => f.jid) });
    }
  },
  {
    ...base, hidden: true, names: ['ترك'], usage: 'ترك @عضو', desc: 'استثناء عضو',
    async run({ m, chat, args, reply }) {
      const meta = await getMeta(chat);
      const list = targets(m, args);
      if (!list.length) return reply({ img: 'spare', persona: '🤝 من أترك؟', title: 'ترك', body: 'منشن العضو أو رد عليه أو اكتب رقمه.\n*.ترك @عضو*' });
      const infos = list.map(t => partInfo(meta, t));
      antibots.spare(chat, infos.flatMap(i => [i.tag, i.key]));
      await reply({ img: 'spare', persona: '🤝 تركته.. ولن أعود إليه.', title: 'ترك', body: infos.map(i => `✅ @${i.tag}`).join('\n') + '\n> مستثنى من فحص البوتات دائماً.', mentions: infos.map(i => i.jid) });
    }
  },
  {
    ...base, names: ['مسح المتروكين'], usage: 'مسح المتروكين', desc: 'إعادة فحص الجميع',
    async run({ g, reply }) {
      const n = g.spared.length;
      g.spared = []; db.save();
      await reply({ img: 'spare', persona: '🛡️ صفحة جديدة.. الجميع تحت الفحص.', title: 'مسح المتروكين', body: `🧹 تم مسح ${n} من قائمة الترك.` });
    }
  },

  /* ═══ الروابط (كل الروابط أو روابط واتساب فقط) ═══ */
  {
    ...base, botAdmin: true, names: ['منع الروابط'], usage: 'منع الروابط [واتساب]', desc: 'حذف الروابط مع إنذار',
    async run({ g, args, reply }) {
      g.antilink = true;
      g.linkMode = /واتس|واتساب|قروب|whatsapp/i.test(args.join(' ')) ? 'wa' : 'all';
      db.save();
      await reply({ img: 'link', persona: '🔗 الروابط لا تعبر من هنا.', title: 'منع الروابط', body: `✅ تم التفعيل: ${g.linkMode === 'wa' ? 'روابط المجموعات والقنوات فقط' : 'كل الروابط'}.\n⚠️ الرابط يُحذف ويُنذر صاحبه.\n> *.منع الروابط واتساب* ← روابط واتساب فقط` });
    }
  },
  {
    ...base, names: ['ايقاف منع الروابط', 'سماح الروابط'], usage: 'ايقاف منع الروابط', desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g.antilink = false; db.save();
      await reply({ img: 'link', persona: '🛡️ خفّفت القيد بأمر المشرف.', title: 'منع الروابط', body: '⛔ تم الإيقاف.' });
    }
  },

  /* ═══ السبام (مع اختيار الإجراء) ═══ */
  {
    ...base, botAdmin: true, names: ['منع السبام'], usage: 'منع السبام [انذار|حذف|طرد]', desc: 'إيقاف الإغراق',
    async run({ g, args, reply }) {
      g.antispam = true;
      const a = SPAM_ACTIONS[(args[0] || '').replace(/[إأ]/g, 'ا')];
      if (a) g.spamAction = a;
      db.save();
      await reply({ img: 'spam', persona: '🌊 الإغراق ممنوع.. الهدوء قانون.', title: 'منع السبام', body: `✅ تم التفعيل.\n⚡ 7 رسائل خلال 10 ثوانٍ = سبام.\n⚖️ الإجراء: ${SPAM_LABEL[g.spamAction] || SPAM_LABEL.warn}\n> *.منع السبام انذار • حذف • طرد*` });
    }
  },
  {
    ...base, names: ['ايقاف منع السبام', 'سماح السبام'], usage: 'ايقاف منع السبام', desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g.antispam = false; db.save();
      await reply({ img: 'spam', persona: '🛡️ خفّفت القيد بأمر المشرف.', title: 'منع السبام', body: '⛔ تم الإيقاف.' });
    }
  },

  /* ═══ الأنظمة البسيطة ═══ */
  ...toggles,

  /* ═══ كلمات السب المضافة ═══ */
  {
    ...base, names: ['اضف كلمة', 'اضافة كلمة'], usage: 'اضف كلمة ...', desc: 'كلمة ممنوعة جديدة',
    async run({ g, text, reply }) {
      const w = normalizeText(text);
      if (!w) return reply({ img: 'toxic', persona: '🧼 أي كلمة أمنع؟', title: 'إضافة كلمة', body: '*.اضف كلمة الكلمة*' });
      g.toxicWords = [...new Set([...(g.toxicWords || []), w])].slice(-200); db.save();
      await reply({ img: 'toxic', persona: '🧼 أضفتها للقائمة السوداء.', title: 'إضافة كلمة', body: `✅ ${w[0]}${'•'.repeat(Math.max(1, [...w].length - 1))}\n📝 الكلمات المضافة: ${g.toxicWords.length}${g.antitoxic ? '' : '\n> فعّل النظام: *.منع السب*'}` });
    }
  },
  {
    ...base, names: ['ازل كلمة', 'حذف كلمة'], usage: 'ازل كلمة ...', desc: 'إزالة كلمة ممنوعة',
    async run({ g, text, reply }) {
      const w = normalizeText(text);
      const before = (g.toxicWords || []).length;
      g.toxicWords = (g.toxicWords || []).filter(x => x !== w); db.save();
      await reply({ img: 'toxic', persona: '🧼 تم.', title: 'إزالة كلمة', body: before === g.toxicWords.length ? '⚠️ الكلمة ليست في القائمة.' : '🗑️ حُذفت الكلمة من القائمة.' });
    }
  },
  {
    ...base, names: ['كلمات السب', 'الكلمات الممنوعة'], usage: 'كلمات السب', desc: 'الكلمات المضافة',
    async run({ g, reply }) {
      const list = g.toxicWords || [];
      await reply({ img: 'toxic', persona: '🧼 هذه القائمة السوداء.', title: `الكلمات المضافة (${list.length})`, body: list.length ? list.map((w, i) => `${i + 1}. ${w[0]}${'•'.repeat(Math.max(1, [...w].length - 1))}`).join('\n') : 'لا توجد كلمات مضافة؛ القائمة الأساسية تعمل.' });
    }
  },

  /* ═══ الوضع البطيء ═══ */
  {
    ...base, botAdmin: true, names: ['وضع بطيء', 'الوضع البطيء'], usage: 'وضع بطيء 30', desc: 'رسالة كل مدة',
    async run({ g, args, reply }) {
      const s = Number(String(args[0] || '30').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g, '')) || 30;
      if (s < 5 || s > 3600) return reply({ img: 'slow', persona: '🐢 مدة غير مناسبة.', title: 'الوضع البطيء', body: 'المدة بين 5 ثوانٍ وساعة.\n*.وضع بطيء 30*' });
      g.slowmode = s; db.save();
      await reply({ img: 'slow', persona: '🐢 على مهلكم.. رسالة ثم انتظار.', title: 'الوضع البطيء', body: `✅ رسالة واحدة كل ${s} ثانية لكل عضو.\n🧹 الأسرع تُحذف. المشرفون مستثنون.` });
    }
  },
  {
    ...base, names: ['ايقاف الوضع البطيء', 'ايقاف وضع بطيء'], usage: 'ايقاف الوضع البطيء', desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g.slowmode = 0; db.save();
      await reply({ img: 'slow', persona: '🛡️ عادت السرعة الطبيعية.', title: 'الوضع البطيء', body: '⛔ تم الإيقاف.' });
    }
  },

  /* ═══ الإشراف ═══ */
  {
    ...base, botAdmin: true, names: ['حماية الادمن', 'حماية الاشراف'], usage: 'حماية الادمن', desc: 'منع سحب الإشراف',
    async run({ g, reply }) {
      g.antitakeover = true; db.save();
      await reply({ img: 'takeover', persona: '👑 الإشراف أمانة.. وأنا حارسها.', title: 'حماية الإشراف', body: '✅ من يسحب إشراف غيره يُسحب منه.\n✅ من يطرد 3 أعضاء خلال دقيقة يُسحب منه.\n✅ من يطرد المطور يُسحب منه ويعود المطور.' });
    }
  },
  {
    ...base, names: ['ايقاف حماية الادمن', 'ايقاف حماية الاشراف'], usage: 'ايقاف حماية الادمن', desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g.antitakeover = false; db.save();
      await reply({ img: 'takeover', persona: '🛡️ رفعت يدي عن الإشراف بأمرك.', title: 'حماية الإشراف', body: '⛔ تم الإيقاف.' });
    }
  },
  {
    ...base, botAdmin: true, names: ['منع الترقية', 'مضاد الادمن'], usage: 'منع الترقية', desc: 'منع ترقية بلا إذن',
    async run({ g, reply }) {
      g.antipromote = true; db.save();
      await reply({ img: 'antipromote', persona: '🚨 الإشراف لا يُوزّع بلا إذن.', title: 'منع الترقية', body: '✅ من يرقّي عضواً يدوياً يُنزع إشرافه هو والمُرقّى.\n✅ الترقية عبر *.رفع* أو من المطور مسموحة.' });
    }
  },
  {
    ...base, names: ['ايقاف منع الترقية', 'ايقاف مضاد الادمن'], usage: 'ايقاف منع الترقية', desc: 'إيقاف النظام',
    async run({ g, reply }) {
      g.antipromote = false; db.save();
      await reply({ img: 'antipromote', persona: '🛡️ الترقية حرة بأمرك.', title: 'منع الترقية', body: '⛔ تم الإيقاف.' });
    }
  },

  /* ═══ الكل ═══ */
  {
    ...base, botAdmin: true, names: ['حماية كاملة', 'تشغيل الحماية'], usage: 'حماية كاملة', desc: 'تشغيل كل الأنظمة',
    async run({ g, chat, reply }) {
      for (const k of FULL) g[k] = true;
      if (g.antibots === 'off') { g.antibots = 'mention'; antibots.start(chat); }
      db.save();
      await reply({ img: 'shield', persona: '🛡️ الدروع كلها مرفوعة.', title: 'حماية كاملة', body: '✅ الروابط • جهات الاتصال • السبام\n✅ الكراش • المنشن • السب\n✅ حماية الإشراف • منع الترقية\n✅ البوتات (بإشارة)\n> منع الوسائط/الملصقات/الملفات والوضع البطيء تُفعّل يدوياً.' });
    }
  },
  {
    ...base, names: ['ايقاف الحماية'], usage: 'ايقاف الحماية', desc: 'إيقاف كل الأنظمة',
    async run({ g, chat, reply }) {
      for (const k of [...FULL, 'blockMedia', 'blockSticker', 'blockDocument']) g[k] = false;
      g.slowmode = 0;
      g.antibots = 'off'; antibots.stop(chat);
      db.save();
      await reply({ img: 'shield', persona: '🛡️ أنزلت الدروع بأمرك.. وأبقى قريباً.', title: 'ايقاف الحماية', body: '⛔ تم إيقاف كل الأنظمة.' });
    }
  }
];

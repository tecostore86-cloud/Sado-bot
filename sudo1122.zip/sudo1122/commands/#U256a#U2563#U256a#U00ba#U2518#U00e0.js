/* أوامر عامة: القائمة وحالة البوت */
import config from '../config.js';
import db from '../lib/db.js';
import { btn } from '../lib/ui.js';
import { getCommands } from '../lib/router.js';
import { visibleDevs, num } from '../lib/utils.js';

export const CATEGORIES = [
  [1, 'الحماية', 'protect', '⛔️', 'menu1'],
  [2, 'الأدمن', 'admin', '♟️', 'menu2'],
  [3, 'المراقبة', 'watch', '🎋', 'menu3'],
  [4, 'المطور', 'dev', '⚜️', 'menu4']
];

const uptime = () => {
  const s = Math.floor(process.uptime());
  return [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map(v => String(v).padStart(2, '0')).join(':');
};

function pickCat(arg = '') {
  const a = arg.replace(/[أإآ]/g, 'ا');
  return CATEGORIES.find(c => String(c[0]) === a || c[1].replace(/[أإآ]/g, 'ا') === a || c[2] === a);
}

export default [
  {
    cat: 'general', names: ['اوامر', 'الاوامر', 'menu', 'القائمة'], usage: 'اوامر', desc: 'قائمة الأوامر',
    async run({ m, args, prefix, phrase, reply }) {
      const cat = pickCat(args[0]);
      if (args[0] && !cat) return reply({ img: 'menu', persona: '🛡️ هذا القسم لا أعرفه.', title: 'الأقسام', body: 'اختر رقماً من 1 إلى 4.' });

      if (!cat) {
        const now = new Date();
        const date = now.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });
        return reply({
          img: 'menu',
          persona: '🛡️ أنا درع هذه المجموعة.. اختر قسمك.',
          title: config.info.nameBot,
          body:
`رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ
╭─┈─┈─┈─⟞🌑⟝─┈─┈─┈─╮
┃ ⌯🍂︙ اهلاً ← *@${m.sender.split('@')[0]}*
┃ ⌯🚀︙ التشغيل ← ${uptime()}
┃ ⌯👾︙ التاريخ ← ${date}
╰─┈─┈─┈─⟞🌑⟝─┈─┈─┈─╯
` + CATEGORIES.map(c => `${c[3]} *${prefix}${phrase} ${c[0]}* ← ${c[1]}`).join('\n'),
          mentions: [m.sender],
          buttons: [btn.list('🎫 الأقسام', [{
            title: '🌳 الأقسام',
            rows: CATEGORIES.map(c => ({ title: `${c[0]} ~ ${c[1]} ${c[3]}`, description: `عرض أوامر ${c[1]}`, id: `${prefix}${phrase} ${c[0]}` }))
          }])]
        });
      }

      const list = getCommands().filter(c => c.cat === cat[2] && !c.hidden);
      return reply({
        img: cat[4],
        persona: `${cat[3]} قسم ${cat[1]}.. الأوامر طوع أمرك.`,
        title: `قسم ${cat[1]}`,
        body: list.map(c => `${cat[3]} *${prefix}${c.usage}*\n   ╰ ${c.desc}`).join('\n')
      });
    }
  },
  {
    cat: 'general', names: ['البوت', 'بوت', 'بسس', 'تجتوج', 'ping'], usage: 'البوت', desc: 'حالة البوت',
    async run({ reply }) {
      const dev = visibleDevs().find(d => d.main) || visibleDevs()[0];
      const groups = Object.values(db.data.groups).filter(g =>
        g.antilink || g.anticontact || g.antispam || g.anticrash || g.antimention || g.antitakeover || (g.antibots && g.antibots !== 'off')).length;
      const cmds = getCommands().length;
      const mem = (process.memoryUsage().rss / 1048576).toFixed(0);
      await reply({
        img: 'info',
        persona: '🛡️ حاضر.. والدرع مرفوع.',
        title: 'حالة البوت',
        body: [
          `🤖 الاسم: ${config.info.nameBot}`,
          `📜 الأوامر: ${cmds} أمر`,
          `🛡️ مجموعات محمية: ${groups}`,
          `⏱️ التشغيل: ${uptime()}`,
          `💾 الذاكرة: ${mem}MB`,
          dev ? `👑 المطور: ${dev.name}\n🔗 wa.me/${num(dev.number)}` : ''
        ].filter(Boolean).join('\n')
      });
    }
  }
];

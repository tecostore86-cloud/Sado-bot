/* قسم الأدمن — إدارة المجموعة */
import db from '../lib/db.js';
import { kick } from '../lib/warns.js';
import { btn } from '../lib/ui.js';
import { greet, TEMPLATES } from '../lib/notify.js';
import { targets, partInfo, getMeta, dropMeta, num, isDevNumber } from '../lib/utils.js';

const base = { cat: 'admin', group: true, admin: true };
const tags = (list) => list.map(i => `@${i.tag}`).join('، ');

/* ═══ الترحيب والوداع (من ZONE • RAID) ═══ */
function greeting(kind, names, title, img, persona) {
  return {
    ...base, names, usage: `${names[0]} [تشغيل|ايقاف|تجربة|نص]`, desc: kind === 'welcome' ? 'ترحيب بالأعضاء الجدد' : 'وداع المغادرين',
    async run({ m, g, args, chat, prefix, reply, conn }) {
      g[kind] ??= { on: false, text: '' };
      const st = g[kind];
      const a = (args[0] || '').replace(/[إأ]/g, 'ا');
      const cmd = `${prefix}${names[0]}`;
      if (['تجربة', 'جرب', 'test'].includes(a)) {
        const meta = await getMeta(chat);
        return greet(chat, kind, m.sender, meta, '', conn);
      }
      let line = '';
      if (['تشغيل', 'تفعيل', 'on'].includes(a)) { st.on = true; line = '✅ تم التفعيل.'; }
      else if (['ايقاف', 'تعطيل', 'off'].includes(a)) { st.on = false; line = '⛔ تم الإيقاف.'; }
      else if (['افتراضي', 'reset'].includes(a)) { st.text = ''; line = '✅ عادت الرسائل العشوائية.'; }
      else if (['نص', 'رسالة'].includes(a)) {
        const body = String(m.body || '');
        const value = body.slice(body.indexOf(args[0]) + args[0].length).trim();
        if (!value) return reply({ img, persona, title, body: `اكتب النص بعد الأمر:\n*${cmd} نص مرحباً @عضو في {المجموعة}*\n> المتغيرات: @عضو • {المجموعة} • {العدد}` });
        st.text = value.slice(0, 1000); line = '✅ حُفظ النص الجديد.';
      }
      db.save();
      await reply({
        img, persona, title,
        body: [
          line,
          `📌 الحالة: ${st.on ? '🟢 مفعّل' : '🔴 متوقف'}`,
          `📝 النص: ${st.text ? `\n${st.text}` : `🎲 عشوائي (${TEMPLATES[kind].length} رسائل)`}`,
          `\n> ${cmd} تشغيل • ايقاف • تجربة • افتراضي`,
          `> ${cmd} نص ... (المتغيرات: @عضو {المجموعة} {العدد})`
        ].filter(Boolean).join('\n'),
        buttons: line ? undefined : [
          btn.quick(st.on ? '⛔ ايقاف' : '✅ تشغيل', `${cmd} ${st.on ? 'ايقاف' : 'تشغيل'}`),
          btn.quick('👀 تجربة', `${cmd} تجربة`)
        ]
      });
    }
  };
}

const greetCmds = [
  greeting('welcome', ['الترحيب', 'ترحيب'], 'الترحيب', 'welcome', '👋 من يدخل بأدب.. يُستقبل بحفاوة.'),
  greeting('goodbye', ['الوداع', 'وداع'], 'الوداع', 'goodbye', '🚪 من يغادر.. نودّعه بلطف.'),
  {
    ...base, names: ['الاشعارات', 'تشغيل الاشعارات'], usage: 'الاشعارات', desc: 'الإعلان عن كل تعديل',
    async run({ g, reply }) {
      g.notify = true; db.save();
      await reply({ img: 'notify', persona: '🔔 لن يمرّ تعديل دون أن أعلنه.', title: 'الإشعارات', body: '✅ تم التفعيل.\n🔔 إضافة/نزع مشرف • إضافة/طرد/خروج عضو\n🔔 الاسم • الوصف • الصورة • القفل • الرابط • الإعدادات' });
    }
  },
  {
    ...base, names: ['ايقاف الاشعارات'], usage: 'ايقاف الاشعارات', desc: 'إيقاف الإعلانات',
    async run({ g, reply }) {
      g.notify = false; db.save();
      await reply({ img: 'notify', persona: '🔕 سأراقب بصمت.', title: 'الإشعارات', body: '⛔ تم الإيقاف.' });
    }
  }
];

export default [
  {
    ...base, botAdmin: true, names: ['ضيف', 'اضف', 'اضافة'], usage: 'ضيف رقم', desc: 'إضافة عضو',
    async run({ m, conn, chat, args, reply }) {
      const list = targets(m, args);
      if (!list.length) return reply({ img: 'add', persona: '➕ من أُدخل؟', title: 'إضافة', body: 'اكتب الرقم مع رمز الدولة أو رد على رسالة الشخص.\n*.ضيف 212612345678*' });
      const res = await conn.groupParticipantsUpdate(chat, list.map(j => `${num(j)}@s.whatsapp.net`), 'add').catch(e => ({ error: e.message }));
      dropMeta(chat);
      if (res?.error) throw new Error(res.error);
      const lines = (res || []).map(r => {
        const n = num(r.jid || r.id);
        const st = String(r.status);
        if (st === '200') return `✅ +${n} أُضيف`;
        if (st === '403') return `📨 +${n} يمنع الإضافة — أُرسلت له دعوة`;
        if (st === '409') return `ℹ️ +${n} موجود مسبقاً`;
        if (st === '408') return `⏳ +${n} خرج مؤخراً، حاول لاحقاً`;
        return `❌ +${n} تعذّرت إضافته (${st})`;
      });
      await reply({ img: 'add', persona: '➕ الباب مفتوح لمن تختارون.', title: 'إضافة', body: lines.join('\n') || '✅ تم.' });
    }
  },
  {
    ...base, botAdmin: true, names: ['طرد', 'اطرد', 'kick'], usage: 'طرد @عضو', desc: 'طرد عضو',
    async run({ m, chat, args, reply, isDev }) {
      const meta = await getMeta(chat, undefined, true);
      const list = targets(m, args).map(t => partInfo(meta, t));
      if (!list.length) return reply({ img: 'kick', persona: '🚪 من يخرج؟', title: 'طرد', body: 'منشن العضو أو رد على رسالته.' });
      const me = partInfo(meta, m.sender);
      if (list.some(i => i.isDev || i.isBot)) {
        if (!isDev && !me.isSuper) {
          await reply({ img: 'kick', persona: '⚜️ تمدّ يدك على الحارس؟', title: 'طرد', body: `لا يُطرد المطور ولا البوت.\n🚪 @${me.tag} خارجاً.`, mentions: [me.jid] });
          return kick(chat, me.jid);
        }
        return reply({ img: 'deny', persona: '⚜️ لا أطرد نفسي ولا المطور.', title: 'طرد', body: 'اختر عضواً آخر.' });
      }
      const ok = list.filter(i => i.inGroup && !i.isSuper);
      if (!ok.length) return reply({ img: 'kick', persona: '🚪 لا أجده بيننا.', title: 'طرد', body: 'العضو غير موجود أو هو منشئ المجموعة.' });
      await kick(chat, ok.map(i => i.jid));
      await reply({ img: 'kick', persona: '🚪 خرج.. والباب يُغلق خلفه.', title: 'طرد', body: `✅ ${tags(ok)}`, mentions: ok.map(i => i.jid) });
    }
  },
  {
    ...base, botAdmin: true, names: ['رفع', 'ترقية'], usage: 'رفع @عضو', desc: 'ترقية لمشرف',
    async run({ m, conn, chat, args, reply }) {
      const meta = await getMeta(chat);
      const list = targets(m, args).map(t => partInfo(meta, t)).filter(i => i.inGroup);
      if (!list.length) return reply({ img: 'promote', persona: '⬆️ من أرفع؟', title: 'رفع', body: 'منشن العضو أو رد على رسالته.' });
      await conn.groupParticipantsUpdate(chat, list.map(i => i.jid), 'promote');
      dropMeta(chat);
      await reply({ img: 'promote', persona: '⬆️ صار من حرّاس المجموعة.', title: 'رفع', body: `✅ ${tags(list)}`, mentions: list.map(i => i.jid) });
    }
  },
  {
    ...base, botAdmin: true, names: ['خفض', 'تنزيل'], usage: 'خفض @عضو', desc: 'سحب الإشراف',
    async run({ m, conn, chat, args, reply, isDev }) {
      const meta = await getMeta(chat);
      const list = targets(m, args).map(t => partInfo(meta, t)).filter(i => i.inGroup);
      if (!list.length) return reply({ img: 'demote', persona: '⬇️ من أُنزل؟', title: 'خفض', body: 'منشن المشرف أو رد على رسالته.' });
      const ok = list.filter(i => !i.isBot && !i.isSuper && (isDev || !i.isDev));
      if (!ok.length) return reply({ img: 'deny', persona: '⚜️ هذا خارج يدك.', title: 'خفض', body: 'لا يمكن خفض البوت أو المطور أو منشئ المجموعة.' });
      await conn.groupParticipantsUpdate(chat, ok.map(i => i.jid), 'demote');
      dropMeta(chat);
      await reply({ img: 'demote', persona: '⬇️ عاد عضواً كما كان.', title: 'خفض', body: `✅ ${tags(ok)}`, mentions: ok.map(i => i.jid) });
    }
  },
  {
    ...base, botAdmin: true, names: ['قفل', 'اغلاق', 'قفل الشات'], usage: 'قفل', desc: 'المشرفون فقط يكتبون',
    async run({ conn, chat, reply }) {
      await conn.groupSettingUpdate(chat, 'announcement');
      dropMeta(chat);
      await reply({ img: 'lock', persona: '🔒 صمتٌ مؤقت.. للحماية.', title: 'قفل الشات', body: '✅ المشرفون فقط يمكنهم الكتابة.' });
    }
  },
  {
    ...base, botAdmin: true, names: ['فتح', 'فتح الشات'], usage: 'فتح', desc: 'الجميع يكتبون',
    async run({ conn, chat, reply }) {
      await conn.groupSettingUpdate(chat, 'not_announcement');
      dropMeta(chat);
      await reply({ img: 'unlock', persona: '🔓 عاد الكلام.. وعيني تراقب.', title: 'فتح الشات', body: '✅ يمكن للجميع الكتابة.' });
    }
  },
  {
    ...base, names: ['حذف', 'مسح'], usage: 'حذف (بالرد)', desc: 'حذف رسالة',
    async run({ m, botAdmin, reply }) {
      if (!m.quoted) return reply({ img: 'delete', persona: '🗑️ أي رسالة؟', title: 'حذف', body: 'رد على الرسالة التي تريد حذفها.' });
      if (!m.quoted.fromMe && !botAdmin) return reply({ img: 'deny', persona: '🛡️ أعطني الإشراف لأحذف رسائلهم.', title: 'أحتاج الإشراف', body: 'لا أستطيع حذف رسائل الأعضاء قبل أن أصبح مشرفاً.' });
      await m.quoted.delete();
      await m.delete().catch(() => {});
    }
  },
  {
    ...base, names: ['منشن', 'مخفي'], usage: 'منشن نص', desc: 'تنبيه كل الأعضاء',
    async run({ conn, chat, text, m, reply }) {
      const meta = await getMeta(chat);
      const all = meta.participants.map(p => p.id);
      const msg = text || m.quoted?.text || '📢';
      await conn.sendMessage(chat, { text: msg, mentions: all });
    }
  },
  {
    ...base, botAdmin: true, names: ['رابط', 'الرابط', 'لينك'], usage: 'رابط', desc: 'رابط المجموعة',
    async run({ conn, chat, reply }) {
      const code = await conn.groupInviteCode(chat);
      await reply({ img: 'invite', persona: '🔗 هذا مفتاح الباب.. احفظوه.', title: 'رابط المجموعة', body: `https://chat.whatsapp.com/${code}` });
    }
  },
  {
    ...base, botAdmin: true, names: ['تغيير الرابط', 'الغاء الرابط'], usage: 'تغيير الرابط', desc: 'إلغاء الرابط القديم',
    async run({ conn, chat, reply }) {
      const code = await conn.groupRevokeInvite(chat);
      await reply({ img: 'revoke', persona: '♻️ المفتاح القديم كُسر.', title: 'تغيير الرابط', body: `✅ الرابط الجديد:\nhttps://chat.whatsapp.com/${code}` });
    }
  },
  {
    ...base, names: ['وضع الادمن'], usage: 'وضع الادمن', desc: 'البوت للمشرفين فقط',
    async run({ g, reply }) {
      g.adminOnly = true; db.save();
      await reply({ img: 'adminmode', persona: '👑 لا أسمع هنا إلا المشرفين.', title: 'وضع الأدمن', body: '✅ البوت يرد على المشرفين فقط.' });
    }
  },
  {
    ...base, names: ['ايقاف وضع الادمن'], usage: 'ايقاف وضع الادمن', desc: 'البوت للجميع',
    async run({ g, reply }) {
      g.adminOnly = false; db.save();
      await reply({ img: 'adminmode', persona: '🛡️ عدت أسمع الجميع.', title: 'وضع الأدمن', body: '⛔ البوت يرد على كل الأعضاء.' });
    }
  },

  ...greetCmds
];

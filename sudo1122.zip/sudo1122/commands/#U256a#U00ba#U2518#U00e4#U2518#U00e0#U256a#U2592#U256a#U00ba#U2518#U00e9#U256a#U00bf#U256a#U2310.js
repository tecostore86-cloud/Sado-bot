/* قسم المراقبة — الإنذارات */
import db from '../lib/db.js';
import { addWarn, LIMIT } from '../lib/warns.js';
import { targets, partInfo, getMeta, num } from '../lib/utils.js';

const base = { cat: 'watch', group: true };

/* ═══ الكتم (من ZONE • RAID): مدة بالدقائق/الساعات/الأيام ═══ */
const MIN = 60000, HOUR = 60 * MIN, DAY = 24 * HOUR;
function parseDuration(args) {
  const t = args.join(' ').replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const mm = t.match(/(\d+)\s*(ث|ثانية|ثواني|د|دقيقة|دقائق|دقايق|س|ساعة|ساعات|ي|يوم|ايام|أيام|m|h|d)?(?=\s|$)/i);
  if (!mm) return null;
  const v = Number(mm[1]);
  const u = mm[2] || 'د';
  if (/^(ث|ثانية|ثواني)$/.test(u)) return v * 1000;
  if (/^(س|ساعة|ساعات|h)$/i.test(u)) return v * HOUR;
  if (/^(ي|يوم|ايام|أيام|d)$/i.test(u)) return v * DAY;
  return v * MIN;
}
function human(ms) {
  const w = (n, one, few, many) => `${n} ${n >= 3 && n <= 10 ? few : n > 10 ? many : one}`;
  if (ms >= DAY) return w(Math.round(ms / DAY), 'يوم', 'أيام', 'يوماً');
  if (ms >= HOUR) return w(Math.round(ms / HOUR), 'ساعة', 'ساعات', 'ساعة');
  return w(Math.max(1, Math.round(ms / MIN)), 'دقيقة', 'دقائق', 'دقيقة');
}

const muteCmds = [
  {
    ...base, admin: true, botAdmin: true, names: ['كتم', 'اسكات'], usage: 'كتم @عضو 10د', desc: 'حذف رسائله مؤقتاً',
    async run({ m, chat, args, g, reply }) {
      const meta = await getMeta(chat);
      const [t] = targets(m, args.filter(a => !/^\d{1,4}\D*$/.test(a)));
      if (!t) return reply({ img: 'mute', persona: '🔇 من أُسكت؟', title: 'كتم', body: 'منشن العضو أو رد عليه مع المدة.\n*.كتم @عضو 10د*\n> د دقيقة • س ساعة • ي يوم' });
      const info = partInfo(meta, t);
      if (!info.inGroup) return reply({ img: 'mute', persona: '🔇 لا أجده بيننا.', title: 'كتم', body: 'العضو غير موجود في المجموعة.' });
      if (info.isAdmin || info.isDev || info.isBot) return reply({ img: 'deny', persona: '⚜️ المشرفون لا يُكتمون.', title: 'كتم', body: 'لا يمكن كتم مشرف أو مطور أو البوت.' });
      const ms = Math.min(Math.max(parseDuration(args.filter(a => !a.startsWith('@'))) ?? 10 * MIN, MIN), 7 * DAY);
      g.mutes ??= {};
      g.mutes[info.key] = { until: Date.now() + ms, jid: info.jid };
      db.save();
      await reply({ img: 'mute', persona: '🔇 صمتٌ إجباري.. كل رسالة ستُمسح.', title: 'كتم', body: `👤 @${info.tag}\n⏰ المدة: ${human(ms)}\n🧹 رسائله تُحذف تلقائياً.\n> لإلغائه: *.الغاء كتم @عضو*`, mentions: [info.jid] });
    }
  },
  {
    ...base, admin: true, names: ['الغاء كتم', 'فك الكتم', 'فك كتم'], usage: 'الغاء كتم @عضو', desc: 'إعادة الكلام',
    async run({ m, chat, args, g, reply }) {
      const meta = await getMeta(chat);
      const [t] = targets(m, args);
      if (!t) return reply({ img: 'unmute', persona: '🔊 من أُطلق؟', title: 'إلغاء الكتم', body: '*.الغاء كتم @عضو*' });
      const info = partInfo(meta, t);
      if (!g.mutes?.[info.key]) return reply({ img: 'unmute', persona: '🔊 صوته لم يُسلب أصلاً.', title: 'إلغاء الكتم', body: `@${info.tag} غير مكتوم.`, mentions: [info.jid] });
      delete g.mutes[info.key]; db.save();
      await reply({ img: 'unmute', persona: '🔊 عاد صوته.. فليحسن استعماله.', title: 'إلغاء الكتم', body: `✅ @${info.tag} يمكنه الكتابة الآن.`, mentions: [info.jid] });
    }
  },
  {
    ...base, admin: true, names: ['المكتومين', 'قائمة المكتومين'], usage: 'المكتومين', desc: 'قائمة المكتومين',
    async run({ g, reply }) {
      const now = Date.now();
      for (const [k, v] of Object.entries(g.mutes || {})) if (v.until <= now) delete g.mutes[k];
      db.save();
      const list = Object.entries(g.mutes || {});
      await reply({
        img: 'mutes', persona: '🔇 هؤلاء في الصمت الآن.', title: `المكتومون (${list.length})`,
        body: list.length ? list.map(([k, v], i) => `${i + 1}. @${num(v.jid) || k} ← ${human(v.until - now)}`).join('\n') : 'لا يوجد مكتومون حالياً.',
        mentions: list.map(([, v]) => v.jid).filter(Boolean)
      });
    }
  }
];

export default [
  ...muteCmds,
  {
    ...base, admin: true, botAdmin: true, names: ['انذار', 'تحذير', 'warn'], usage: 'انذار @عضو', desc: 'إعطاء إنذار',
    async run({ m, chat, args, reply }) {
      const meta = await getMeta(chat);
      const [t] = targets(m, args);
      if (!t) return reply({ img: 'warn', persona: '⚠️ لمن الإنذار؟', title: 'إنذار', body: 'منشن العضو أو رد على رسالته.\n*.انذار @عضو السبب*' });
      const info = partInfo(meta, t);
      if (!info.inGroup) return reply({ img: 'warn', persona: '⚠️ لا أجده بيننا.', title: 'إنذار', body: 'العضو غير موجود في المجموعة.' });
      if (info.isAdmin || info.isDev || info.isBot) return reply({ img: 'deny', persona: '⚜️ المشرفون لا يُنذَرون هنا.', title: 'إنذار', body: 'لا يمكن إنذار مشرف أو مطور أو البوت.' });
      const reason = args.filter(a => !/^@?\+?\d{5,}$/.test(a)).join(' ') || 'مخالفة القوانين';
      await addWarn(chat, info, reason, { quoted: m.raw, by: partInfo(meta, m.sender) });
    }
  },
  {
    ...base, admin: true, names: ['حذف انذار', 'حذف الانذار', 'الغاء انذار'], usage: 'حذف انذار @عضو', desc: 'إزالة إنذار',
    async run({ m, chat, args, g, reply }) {
      const meta = await getMeta(chat);
      const [t] = targets(m, args);
      if (!t) return reply({ img: 'unwarn', persona: '✅ عمّن أرفع الإنذار؟', title: 'حذف إنذار', body: 'منشن العضو أو رد على رسالته.' });
      const info = partInfo(meta, t);
      const cur = g.warnings[info.key] || 0;
      if (!cur) return reply({ img: 'unwarn', persona: '✅ سجله نظيف أصلاً.', title: 'حذف إنذار', body: `@${info.tag} ليس لديه إنذارات.`, mentions: [info.jid] });
      if (cur - 1 <= 0) delete g.warnings[info.key]; else g.warnings[info.key] = cur - 1;
      db.save();
      await reply({ img: 'unwarn', persona: '✅ صفحة أخف.. فلا تعد.', title: 'حذف إنذار', body: `👤 @${info.tag}\n📊 المتبقي: ${Math.max(cur - 1, 0)}/${LIMIT()}`, mentions: [info.jid] });
    }
  },
  {
    ...base, admin: true, names: ['تصفير الانذارات'], usage: 'تصفير الانذارات', desc: 'مسح كل الإنذارات',
    async run({ m, chat, args, g, reply }) {
      const list = targets(m, args);
      if (list.length) {
        const meta = await getMeta(chat);
        const info = partInfo(meta, list[0]);
        delete g.warnings[info.key]; db.save();
        return reply({ img: 'unwarn', persona: '✅ سجله صار أبيض.', title: 'تصفير', body: `👤 @${info.tag} بلا إنذارات الآن.`, mentions: [info.jid] });
      }
      const n = Object.keys(g.warnings).length;
      g.warnings = {}; db.save();
      await reply({ img: 'unwarn', persona: '✅ بداية جديدة للجميع.', title: 'تصفير الإنذارات', body: `🧹 تم مسح إنذارات ${n} عضو.` });
    }
  },
  {
    ...base, admin: true, names: ['الانذارات', 'قائمة الانذارات', 'warns'], usage: 'الانذارات', desc: 'قائمة المنذَرين',
    async run({ chat, g, reply }) {
      const meta = await getMeta(chat);
      const entries = Object.entries(g.warnings).filter(([, c]) => c > 0);
      if (!entries.length) return reply({ img: 'warns', persona: '📋 المجموعة منضبطة.', title: 'الإنذارات', body: 'لا توجد إنذارات حالياً.' });
      const infos = entries.map(([k, c]) => ({ ...partInfo(meta, k), c }));
      await reply({
        img: 'warns', persona: '📋 هذا سجل المخالفين.', title: `الإنذارات (${infos.length})`,
        body: infos.map((i, n) => `${n + 1}. @${i.tag} ← ${i.c}/${LIMIT()}`).join('\n'),
        mentions: infos.map(i => i.jid)
      });
    }
  },
  {
    ...base, names: ['انذاراتي', 'warnings'], usage: 'انذاراتي', desc: 'عدد إنذاراتك',
    async run({ m, chat, g, reply }) {
      const meta = await getMeta(chat);
      const info = partInfo(meta, m.sender);
      const c = g.warnings[info.key] || 0;
      await reply({
        img: 'warns', persona: c ? '⚠️ عدّادك يعمل.. فانتبه.' : '✅ سجلك نظيف.',
        title: 'إنذاراتي',
        body: `👤 @${info.tag}\n📊 ${c}/${LIMIT()}${c ? `\n> عند ${LIMIT()} إنذارات يتم الطرد.` : ''}`,
        mentions: [info.jid]
      });
    }
  }
];

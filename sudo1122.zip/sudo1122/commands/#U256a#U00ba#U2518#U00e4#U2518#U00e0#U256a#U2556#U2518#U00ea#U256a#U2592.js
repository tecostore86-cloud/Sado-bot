/* قسم المطور — إدارة المطورين والخاص */
import config from '../config.js';
import db from '../lib/db.js';
import { allDevs, visibleDevs, num, targets, getMeta, partInfo } from '../lib/utils.js';

const base = { cat: 'dev', dev: true };

/* استخراج رقم من منشن/رد/نص */
async function pickNumber(m, args, chat) {
  const [t] = targets(m, args);
  if (!t) return null;
  if (chat.endsWith('@g.us') && !t.endsWith('@s.whatsapp.net')) {
    const info = partInfo(await getMeta(chat), t);
    return info.phone || null;
  }
  return num(t);
}

export default [
  {
    ...base, names: ['ضيف مطور', 'اضف مطور'], usage: 'ضيف مطور رقم', desc: 'إضافة مطور',
    async run({ m, chat, args, reply }) {
      const n = await pickNumber(m, args, chat);
      if (!n || n.length < 8) return reply({ img: 'devadd', persona: '⚜️ من ينضم للنخبة؟', title: 'إضافة مطور', body: 'اكتب الرقم مع رمز الدولة أو منشن الشخص.\n*.ضيف مطور 212612345678 الاسم*\n> أضف كلمة *مخفي* ليكون غير ظاهر.' });
      if (allDevs().some(d => d.number === n)) return reply({ img: 'devadd', persona: '⚜️ هو منّا أصلاً.', title: 'إضافة مطور', body: `+${n} مطور بالفعل.` });
      const hidden = args.includes('مخفي');
      const name = args.filter(a => !/\d{6,}/.test(a) && a !== 'مخفي' && !a.startsWith('@')).join(' ') || '';   // بدون اسم ← يُستعمل اسمه في واتساب
      db.data.devs.push({ name, number: n, hidden });
      db.save();
      await reply({ img: 'devadd', persona: '⚜️ انضم حارس جديد.', title: 'إضافة مطور', body: `✅ ${name ? `${name} • ` : ''}+${n}${hidden ? '\n🕶️ مخفي' : ''}` });
    }
  },
  {
    ...base, names: ['ازل مطور', 'حذف مطور', 'ازالة مطور'], usage: 'ازل مطور رقم', desc: 'إزالة مطور',
    async run({ m, chat, args, reply }) {
      const n = await pickNumber(m, args, chat);
      if (!n) return reply({ img: 'devdel', persona: '⚜️ من يغادر النخبة؟', title: 'إزالة مطور', body: '*.ازل مطور 212612345678*' });
      if (config.developers.some(d => num(d.number) === n)) return reply({ img: 'deny', persona: '⚜️ هذا من الأساس.. لا يُزال.', title: 'إزالة مطور', body: 'المطورون الأساسيون يُعدّلون من ملف config.js فقط.' });
      const before = db.data.devs.length;
      db.data.devs = db.data.devs.filter(d => num(d.number) !== n);
      db.save();
      if (before === db.data.devs.length) return reply({ img: 'devdel', persona: '⚜️ لا أعرفه بيننا.', title: 'إزالة مطور', body: `+${n} ليس مطوراً.` });
      await reply({ img: 'devdel', persona: '⚜️ سُحبت المفاتيح.', title: 'إزالة مطور', body: `✅ تمت إزالة +${n}` });
    }
  },
  {
    ...base, names: ['المطورين', 'قائمة المطورين'], usage: 'المطورين', desc: 'قائمة المطورين',
    async run({ reply }) {
      const list = allDevs();
      await reply({
        img: 'dev', persona: '⚜️ هؤلاء من يملكون المفاتيح.', title: `المطورون (${list.length})`,
        body: list.map((d, i) => `${i + 1}. ${d.name ? `${d.name} • ` : ''}+${d.number}${d.main ? ' 👑' : ''}${d.hidden ? ' 🕶️' : ''}`).join('\n')
      });
    }
  },
  {
    ...base, names: ['قفل الخاص'], usage: 'قفل الخاص', desc: 'الخاص للمطورين فقط',
    async run({ reply }) {
      db.data.settings.privateDevOnly = true; db.save();
      await reply({ img: 'private', persona: '🔐 الخاص مغلق إلا للمطورين.', title: 'الخاص', body: '✅ البوت لا يرد في الخاص إلا على المطورين.' });
    }
  },
  {
    ...base, names: ['فتح الخاص'], usage: 'فتح الخاص', desc: 'الخاص للجميع',
    async run({ reply }) {
      db.data.settings.privateDevOnly = false; db.save();
      await reply({ img: 'private', persona: '🔓 الخاص مفتوح للجميع.', title: 'الخاص', body: '✅ البوت يرد في الخاص على الجميع.' });
    }
  },

  /* منع الخطف (من ZONE • RAID): أغادر إذا أضافني غير المطور */
  {
    ...base, names: ['منع الخطف', 'منع خطف'], usage: 'منع الخطف', desc: 'البوت للمطور فقط',
    async run({ reply }) {
      db.data.settings.antiHijack = true; db.save();
      await reply({ img: 'hijack', persona: '🚫 لا أبقى إلا حيث يضعني المطور.', title: 'منع الخطف', body: '✅ إذا أضافني أي شخص غير المطور إلى مجموعة، أنبّه وأغادر.' });
    }
  },
  {
    ...base, names: ['ايقاف منع الخطف'], usage: 'ايقاف منع الخطف', desc: 'البقاء في أي مجموعة',
    async run({ reply }) {
      db.data.settings.antiHijack = false; db.save();
      await reply({ img: 'hijack', persona: '🛡️ أبقى حيث أُضاف.', title: 'منع الخطف', body: '⛔ تم الإيقاف.' });
    }
  },

  /* عام: معلومات المطور الظاهر */
  {
    cat: 'general', names: ['المطور', 'مطور', 'owner'], usage: 'المطور', desc: 'التواصل مع المطور',
    async run({ reply }) {
      const list = visibleDevs();
      const main = list.find(d => d.main) || list[0];
      await reply({
        img: 'dev', persona: '⚜️ هذا من بنى الدرع.', title: 'المطور',
        body: list.map(d => `${d.main ? '👑' : '⚜️'} ${d.name || `+${d.number}`}\n   wa.me/${d.number}`).join('\n'),
        buttons: main ? [{ name: 'cta_url', params: { display_text: `💬 مراسلة ${main.name || 'المطور'}`, url: `https://wa.me/${main.number}`, merchant_url: `https://wa.me/${main.number}` } }] : undefined
      });
    }
  }
];

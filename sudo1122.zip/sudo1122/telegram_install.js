/**
 * Public Telegram installer for SUDO-BOT.
 * Each customer gets an isolated copy and an independent Node process.
 * Original SUDO source files are copied unchanged into each instance.
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { Telegraf, Markup } from 'telegraf';
import telegramConfig from './config.telegram.js';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(ROOT, 'data');
const INSTANCES_DIR = path.join(ROOT, 'instances');
const OWNERS_FILE = path.join(DATA_DIR, 'telegram-owners.json');
const sessions = new Map();
const workers = new Map();
const cooldowns = new Map();
const dailyAttempts = new Map();
const intentionalStops = new Set();
const restartHistory = new Map();

function readOwners() {
  try {
    const value = JSON.parse(fs.readFileSync(OWNERS_FILE, 'utf8'));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch { return {}; }
}
const owners = readOwners();

function saveOwners() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const temp = `${OWNERS_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(owners, null, 2), { mode: 0o600 });
  fs.renameSync(temp, OWNERS_FILE);
}

function privateOnly(ctx) {
  return ctx.chat?.type === 'private' && Boolean(ctx.from?.id);
}

function cleanPhone(raw) {
  return String(raw || '').replace(/[+\s\-()]/g, '').replace(/^00/, '');
}

function validPhone(phone) {
  return /^\d{8,15}$/.test(phone);
}

function instancePath(userId) {
  // Telegram IDs are numeric; never use arbitrary user text as a filesystem path.
  return path.join(INSTANCES_DIR, `user-${String(userId).replace(/\D/g, '')}`);
}

function prepareInstance(userId) {
  const dest = instancePath(userId);
  fs.mkdirSync(INSTANCES_DIR, { recursive: true });
  const excluded = new Set([
    'node_modules', 'instances', 'session', 'data', 'sub', '.git',
    'server.js', 'telegram_install.js', 'config.telegram.js', '.env', '.env.example'
  ]);
  fs.mkdirSync(dest, { recursive: true, mode: 0o700 });
  // Sync the original application files on every start, but never overwrite
  // a customer's private data or WhatsApp session directories.
  for (const entry of fs.readdirSync(ROOT)) {
    if (excluded.has(entry)) continue;
    fs.cpSync(path.join(ROOT, entry), path.join(dest, entry), { recursive: true, force: true });
  }
  fs.mkdirSync(path.join(dest, 'data'), { recursive: true, mode: 0o700 });
  fs.mkdirSync(path.join(dest, 'session'), { recursive: true, mode: 0o700 });
  try { fs.chmodSync(dest, 0o700); } catch {}
  return dest;
}

function sendPairCode(bot, userId, phone, code) {
  const message =
    `🔐 كود ربط واتساب جاهز\n\n` +
    `📱 الرقم: ${phone}\n` +
    `🔑 الكود: ${code}\n\n` +
    `طريقة الربط:\n` +
    `1. افتح واتساب على هاتفك\n` +
    `2. الإعدادات ← الأجهزة المرتبطة\n` +
    `3. ربط جهاز ← الربط برقم الهاتف\n` +
    `4. أدخل الكود أعلاه\n\n` +
    `لا تشارك هذا الكود مع أي شخص.`;
  return bot.telegram.sendMessage(userId, message, {
    reply_markup: {
      inline_keyboard: [[
        {
          text: '📋 نسخ الكود',
          copy_text: { text: String(code) }
        }
      ]]
    }
  });
}

function stopWorker(userId) {
  const id = String(userId);
  const worker = workers.get(id);
  intentionalStops.add(id);
  if (!worker) return Promise.resolve();
  if (worker.pairTimer) clearTimeout(worker.pairTimer);
  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      workers.delete(id);
      resolve();
    };
    worker.child.once('exit', done);
    try { worker.child.kill('SIGTERM'); } catch { done(); }
    const force = setTimeout(() => {
      try { worker.child.kill('SIGKILL'); } catch {}
      done();
    }, 4000);
    force.unref?.();
  });
}

function removeInstanceFiles(userId) {
  fs.rmSync(instancePath(userId), { recursive: true, force: true });
}

function startWorker(bot, userId, record, { restoring = false } = {}) {
  const id = String(userId);
  if (workers.has(id)) return workers.get(id);
  intentionalStops.delete(id);
  const cwd = prepareInstance(id);
  const child = spawn(process.execPath, ['index.js'], {
    cwd,
    env: { ...process.env, BOT_NUMBER: record.phone },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  const worker = { child, pairTimer: null, ready: false, phone: record.phone };
  workers.set(id, worker);
  record.status = restoring ? (record.status || 'starting') : 'starting';
  record.instanceDir = path.relative(ROOT, cwd);
  saveOwners();

  const parseLine = async (rawLine) => {
    const line = String(rawLine).replace(/\x1B\[[0-?]*[ -/]*[@-~]/g, '');
    console.log(`[SUDO instance ${id}] ${line}`);
    const pair = line.match(/كود الربط:\s*([A-Z0-9-]{6,})/i);
    if (pair && !worker.ready && owners[id]) {
      owners[id].status = 'pairing';
      saveOwners();
      try { await sendPairCode(bot, id, record.phone, pair[1]); }
      catch (error) { console.error(`[Telegram delivery ${id}]`, error?.message || error); }
    }
    if (/متصل.*الحماية تعمل/.test(line) && !worker.ready) {
      worker.ready = true;
      if (worker.pairTimer) clearTimeout(worker.pairTimer);
      if (owners[id]) {
        const wasConnected = owners[id].status === 'connected';
        owners[id].status = 'connected';
        recordEliteEvent(id, 'connected', owners[id]);
        saveOwners();
        sessions.delete(id);
        if (!wasConnected) {
          try { await bot.telegram.sendMessage(id, `✅ تم اتصال نسخة SUDO-BOT الخاصة بك بنجاح.\n📱 ${record.phone}`); } catch {}
        }
      }
    }
  };

  const out = createInterface({ input: child.stdout });
  const err = createInterface({ input: child.stderr });
  out.on('line', (line) => { void parseLine(line); });
  err.on('line', (line) => console.error(`[SUDO instance ${id}] ${line}`));

  if (!restoring || record.status !== 'connected') worker.pairTimer = setTimeout(async () => {
    if (worker.ready || !owners[id] || workers.get(id) !== worker) return;
    try { await bot.telegram.sendMessage(id, '⏰ انتهت مهلة ربط واتساب. أعد المحاولة باستخدام /install أو ألغِ العملية بواسطة /cancel.'); } catch {}
    await stopWorker(id);
    if (owners[id]) {
      recordEliteEvent(id, 'removed', owners[id]);
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }
    sessions.delete(id);
  }, telegramConfig.pairTimeoutMs);
  worker.pairTimer?.unref?.();

  child.on('error', async (error) => {
    console.error(`[SUDO instance ${id}] spawn error:`, error?.message || error);
  });

  child.on('exit', async (code, signal) => {
    if (workers.get(id) === worker) workers.delete(id);
    if (worker.pairTimer) clearTimeout(worker.pairTimer);
    if (intentionalStops.has(id) || !owners[id]) return;

    owners[id].status = 'restarting';
    saveOwners();
    const now = Date.now();
    const history = (restartHistory.get(id) || []).filter((t) => now - t < 10 * 60_000);
    history.push(now);
    restartHistory.set(id, history);
    if (history.length > telegramConfig.restartLimit) {
      owners[id].status = 'stopped';
      saveOwners();
      try { await bot.telegram.sendMessage(id, '⚠️ توقفت نسختك بعد عدة محاولات تشغيل فاشلة. تواصل مع مسؤول السيرفر.'); } catch {}
      return;
    }
    console.warn(`[SUDO instance ${id}] exited (${code ?? signal}); restarting in 5s`);
    const timer = setTimeout(() => {
      if (owners[id] && !workers.has(id)) startWorker(bot, id, owners[id], { restoring: true });
    }, 5000);
    timer.unref?.();
  });

  return worker;
}

function canAttempt(userId) {
  const id = String(userId);
  const now = Date.now();
  if (now - (cooldowns.get(id) || 0) < telegramConfig.cooldownMs) {
    return { ok: false, reason: 'انتظر قليلاً قبل محاولة تنصيب جديدة.' };
  }
  const day = new Date().toISOString().slice(0, 10);
  const old = dailyAttempts.get(id);
  const count = old?.day === day ? old.count : 0;
  if (count >= telegramConfig.maxDailyAttempts) {
    return { ok: false, reason: 'وصلت إلى الحد اليومي لمحاولات التنصيب. حاول غداً.' };
  }
  cooldowns.set(id, now);
  dailyAttempts.set(id, { day, count: count + 1 });
  return { ok: true };
}

export function startTelegramInstall({ token = telegramConfig.token, allowedIds = telegramConfig.allowedIds, eliteIds = telegramConfig.eliteIds } = {}) {
  const botToken = String(token || '').trim();
  if (!botToken) {
    console.warn('⚠️ [Telegram] اضبط TELEGRAM_BOT_TOKEN في متغيرات بيئة السيرفر.');
    return null;
  }

  const bot = new Telegraf(botToken);
  const allowSet = new Set((allowedIds || []).map(String).filter(Boolean));
  const eliteSet = new Set((eliteIds || []).map(String).filter(Boolean));

  bot.use(async (ctx, next) => {
    if (!privateOnly(ctx)) {
      if (ctx.chat?.type !== 'private') await ctx.reply('🔒 افتح محادثة خاصة مع البوت لاستعمال التنصيب.');
      return;
    }
    if (allowSet.size && !allowSet.has(String(ctx.from.id))) {
      await ctx.reply('🚫 غير مصرح لك باستخدام هذا البوت.');
      return;
    }
    return next();
  });


  const mainMenuFor = (userId) => {
    const rows = [
      [
        Markup.button.callback("📲 تنصيب بوت","ui:install"),
        Markup.button.callback("🤖 نسختي","ui:mybot")
      ],
      [
        Markup.button.callback("📊 حالة الاتصال","ui:status"),
        Markup.button.callback("❓ المساعدة","ui:help")
      ],
      [Markup.button.callback("🗑️ حذف نسختي","ui:remove")]
    ];
    if (eliteSet.has(String(userId))) {
      rows.push([Markup.button.callback("👑 لوحة النخبة","elite:home")]);
    }
    return Markup.inlineKeyboard(rows);
  };

  const backMenu = Markup.inlineKeyboard([
    [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
  ]);

  bot.start(async (ctx) => {
    await ctx.reply(
      '🌌 SUDO-BOT | CONTROL PANEL\n\n' +
      'مرحباً بك في لوحة التحكم الخاصة بك.\n' +
      '━━━━━━━━━━━━━━━━━━\n' +
      '⚡ تنصيب مستقل\n' +
      '🔐 جلسة خاصة بك\n' +
      '🛡️ إدارة ومراقبة النسخة\n' +
      '━━━━━━━━━━━━━━━━━━\n\n' +
      'اختر الخدمة:',
      mainMenuFor(ctx.from.id)
    );
  });

  bot.action('ui:home', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.editMessageText('🌌 SUDO-BOT | CONTROL PANEL\n\nاختر الخدمة:', mainMenuFor(ctx.from.id));
  });

  bot.action('ui:install', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (owners[id]) {
      return ctx.editMessageText('⚠️ لديك نسخة مسجلة بالفعل. افتح قسم نسختي.', backMenu);
    }

    if (sessions.has(id)) {
      return ctx.editMessageText('⏳ لديك عملية جارية بالفعل.', backMenu);
    }

    sessions.set(id, { step: 'await_phone' });

    await ctx.editMessageText(
      '📲 تنصيب نسخة جديدة\n\nأرسل رقم واتساب مع رمز الدولة.\nمثال: 212612345678\n\n⚠️ أرسل رقمك أنت فقط.',
      Markup.inlineKeyboard([
        [Markup.button.callback('❌ إلغاء', 'ui:cancel')],
        [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
      ])
    );
  });

  bot.action(['ui:mybot', 'ui:status'], async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);
    const record = owners[id];

    if (!record) {
      return ctx.editMessageText(
        '🤖 لا توجد لديك نسخة مسجلة حالياً.',
        Markup.inlineKeyboard([
          [Markup.button.callback('📲 تنصيب بوت', 'ui:install')],
          [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
        ])
      );
    }

    const labels = {
      connected: '🟢 متصل',
      pairing: '🟡 في انتظار الربط',
      starting: '🔵 قيد التشغيل',
      restarting: '🟠 إعادة التشغيل',
      stopped: '🔴 متوقف'
    };

    await ctx.editMessageText(
      '🤖 معلومات نسختك\n\n' +
      '📱 الرقم: ' + record.phone + '\n' +
      '🔌 الحالة: ' + (labels[record.status] || record.status || 'غير معروفة') + '\n' +
      '📅 تاريخ التنصيب: ' + (record.createdAt || 'غير معروف'),
      Markup.inlineKeyboard([
        [Markup.button.callback('🔄 تحديث الحالة', 'ui:status')],
        [Markup.button.callback('🗑️ حذف النسخة', 'ui:remove')],
        [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
      ])
    );
  });

  bot.action('ui:help', async (ctx) => {
    await ctx.answerCbQuery();
    await ctx.editMessageText(
      '❓ المساعدة\n\n' +
      '📲 تنصيب بوت: إنشاء نسخة واتساب مستقلة.\n' +
      '🤖 نسختي: عرض معلومات نسختك.\n' +
      '🗑️ حذف نسختي: حذف النسخة وجلسة واتساب.\n\n' +
      '🔐 لا تشارك كود الربط مع أي شخص.',
      backMenu
    );
  });

  bot.action('ui:remove', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!owners[id]) {
      return ctx.editMessageText('لا توجد نسخة مسجلة لحذفها.', backMenu);
    }

    await ctx.editMessageText(
      '⚠️ هل أنت متأكد من حذف نسختك؟\nسيتم إيقافها وحذف جلسة واتساب.',
      Markup.inlineKeyboard([
        [Markup.button.callback('✅ نعم، احذفها', 'ui:remove_confirm')],
        [Markup.button.callback('↩️ رجوع', 'ui:mybot')]
      ])
    );
  });

  bot.action('ui:remove_confirm', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!owners[id]) {
      return ctx.editMessageText('لا توجد نسخة مسجلة.', mainMenuFor(ctx.from.id));
    }

    sessions.delete(id);
    await stopWorker(id);
    recordEliteEvent(id, 'removed', owners[id]);
      delete owners[id];
    saveOwners();
    removeInstanceFiles(id);

    await ctx.editMessageText('✅ تم حذف نسختك وإنهاء جلسة واتساب.', mainMenuFor(ctx.from.id));
  });

  bot.action('ui:cancel', async (ctx) => {
    await ctx.answerCbQuery();
    const id = String(ctx.from.id);

    if (!sessions.has(id)) {
      return ctx.editMessageText('لا توجد عملية جارية.', mainMenuFor(ctx.from.id));
    }

    sessions.delete(id);

    if (owners[id]) {
      await stopWorker(id);
      recordEliteEvent(id, 'removed', owners[id]);
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }

    await ctx.editMessageText('✅ تم إلغاء العملية.', mainMenuFor(ctx.from.id));
  });

  async function beginInstall(ctx, rawPhone) {
    const userId = String(ctx.from.id);
    if (sessions.has(userId)) return ctx.reply('لديك عملية تنصيب جارية. أرسل /cancel لإلغائها.');
    if (owners[userId]) return ctx.reply('لديك نسخة مسجلة بالفعل. استعمل /mybot أو /remove.');
    const attempt = canAttempt(userId);
    if (!attempt.ok) return ctx.reply(`⏳ ${attempt.reason}`);

    const phone = cleanPhone(rawPhone);
    if (!validPhone(phone)) return ctx.reply('⚠️ رقم غير صالح. أرسله مع رمز الدولة، من 8 إلى 15 رقماً، وبدون +.');
    if (Object.values(owners).some((item) => item.phone === phone)) {
      return ctx.reply('⚠️ هذا الرقم مرتبط بالفعل بنسخة أخرى على السيرفر.');
    }
    const max = Math.max(1, Number(telegramConfig.maxTotalBots) || 5);
    if (Object.keys(owners).length >= max) return ctx.reply('⚠️ وصل السيرفر إلى الحد الأقصى للنسخ حالياً. حاول لاحقاً.');

    owners[userId] = { phone, status: 'starting', createdAt: new Date().toISOString() };
    recordEliteEvent(userId, 'install_started', owners[userId]);
    saveOwners();
    sessions.set(userId, { step: 'pairing', phone });
    await ctx.reply(`⏳ جاري إنشاء نسخة مستقلة للرقم ${phone}. سيصلك كود الربط هنا.`);
    try {
      startWorker(bot, userId, owners[userId]);
    } catch (error) {
      recordEliteEvent(userId, 'install_failed', owners[userId]);
      delete owners[userId];
      sessions.delete(userId);
      saveOwners();
      removeInstanceFiles(userId);
      await ctx.reply(`❌ فشل إنشاء النسخة: ${error?.message || error}`);
    }
  }


  
function eliteAllowed(ctx) {
  return eliteSet.has(String(ctx.from?.id || ''));
}

function readEliteLog() {
  try {
    const data = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'elite-history.json'), 'utf8'));
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}

function recordEliteEvent(id, type, record = {}) {
  try {
    const file = path.join(DATA_DIR, 'elite-history.json');
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const logs = readEliteLog();
    logs.unshift({
      userId: String(id),
      type,
      phone: record.phone || '',
      date: new Date().toISOString()
    });
    fs.writeFileSync(file, JSON.stringify(logs.slice(0, 500), null, 2));
  } catch (e) {
    console.error('Elite history:', e.message);
  }
}

function eliteKeyboard() {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('📊 الإحصائيات', 'elite:stats'),
      Markup.button.callback('🤖 إدارة النسخ', 'elite:instances')
    ],
    [
      Markup.button.callback('🟢 النسخ المتصلة', 'elite:connected'),
      Markup.button.callback('🟡 قيد التشغيل', 'elite:pending')
    ],
    [
      Markup.button.callback('👤 المستخدمون', 'elite:users'),
      Markup.button.callback('📜 سجل التنصيبات', 'elite:logs')
    ],
    [
      Markup.button.callback('👥 المجموعات والأعضاء', 'elite:groups'),
      Markup.button.callback('🔄 تحديث', 'elite:refresh')
    ],
    [Markup.button.callback('🏠 الرئيسية', 'ui:home')]
  ]);
}

function eliteBack() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('↩️ رجوع للقائمة الرئيسية', 'elite:home')]
  ]);
}

function eliteStats() {
  const records = Object.entries(owners);
  const result = {
    total: records.length,
    running: workers.size,
    connected: 0,
    pairing: 0,
    stopped: 0,
    groups: 0,
    members: 0,
    admins: 0
  };

  for (const [id, record] of records) {
    if (record.status === 'connected') result.connected++;
    else if (['pairing', 'starting', 'restarting'].includes(record.status)) result.pairing++;
    else result.stopped++;

    try {
      const data = JSON.parse(fs.readFileSync(
        path.join(instancePath(id), 'data', 'elite-stats.json'), 'utf8'
      ));
      result.groups += Number(data.groups) || 0;
      result.members += Number(data.members) || 0;
      result.admins += Number(data.admins) || 0;
    } catch {}
  }
  return result;
}

async function showElite(ctx, section = 'home', edit = true) {
  const st = eliteStats();
  let message = '';
  let keyboard = eliteBack();

  if (section === 'home') {
    message =
      '👑 SUDO ELITE PANEL\n' +
      '━━━━━━━━━━━━━━━━━━\n' +
      'مرحباً بك في لوحة الإدارة\n\n' +
      '🤖 النسخ: ' + st.total + '\n' +
      '🟢 المتصلة: ' + st.connected + '\n' +
      '🟡 قيد التشغيل: ' + st.pairing + '\n' +
      '🔴 المتوقفة: ' + st.stopped + '\n\n' +
      'اختر القسم الذي تريد إدارته:';
    keyboard = eliteKeyboard();
  } else if (section === 'stats') {
    message =
      '📊 إحصائيات السيرفر\n━━━━━━━━━━━━━━━━━━\n' +
      '🤖 مجموع النسخ: ' + st.total + '\n' +
      '⚙️ العمليات النشطة: ' + st.running + '\n' +
      '🟢 المتصلة: ' + st.connected + '\n' +
      '🟡 قيد التشغيل: ' + st.pairing + '\n' +
      '🔴 المتوقفة: ' + st.stopped;
  } else if (section === 'groups') {
    message =
      '👥 إحصائيات المجموعات\n━━━━━━━━━━━━━━━━━━\n' +
      '👥 المجموعات: ' + st.groups + '\n' +
      '🧑‍🤝‍🧑 الأعضاء: ' + st.members + '\n' +
      '🛡️ المشرفون: ' + st.admins;
  } else if (section === 'users' || section === 'instances' ||
             section === 'connected' || section === 'pending') {
    let list = Object.entries(owners);

    if (section === 'connected') list = list.filter(([, r]) => r.status === 'connected');
    if (section === 'pending') list = list.filter(([, r]) =>
      ['starting', 'pairing', 'restarting'].includes(r.status)
    );

    message = section === 'users' ? '👤 المستخدمون المسجلون' :
      section === 'connected' ? '🟢 النسخ المتصلة' :
      section === 'pending' ? '🟡 النسخ قيد التشغيل' : '🤖 إدارة النسخ';

    message += '\n━━━━━━━━━━━━━━━━━━\n';
    message += 'العدد: ' + list.length + '\n\n';

    const rows = [];
    for (const [id, r] of list.slice(0, 35)) {
      const phone = String(r.phone || '');
      const masked = phone.length > 4 ? '******' + phone.slice(-4) : 'غير معروف';
      rows.push([Markup.button.callback(
        '🤖 ' + masked + ' | ' + (r.status || 'غير معروف'),
        'elite:instance:' + id
      )]);
      message += '👤 ' + id + ' — ' + (r.status || 'غير معروف') + '\n';
    }

    if (list.length > 35) message += '\nيعرض أول 35 مستخدماً فقط.';
    keyboard = Markup.inlineKeyboard([
      ...rows,
      [Markup.button.callback('↩️ رجوع', 'elite:home')]
    ]);
  } else if (section === 'logs') {
    const logs = readEliteLog();
    message = '📜 سجل التنصيبات والعمليات\n━━━━━━━━━━━━━━━━━━\n';
    message += 'عدد السجلات: ' + logs.length + '\n\n';

    for (const item of logs.slice(0, 15)) {
      message +=
        '👤 ' + item.userId + '\n' +
        '📌 العملية: ' + item.type + '\n' +
        '📅 ' + item.date + '\n' +
        '━━━━━━━━━━━━━━━━━━\n';
    }
    if (!logs.length) message += 'لا توجد عمليات مسجلة بعد.';
  }

  if (edit) return ctx.editMessageText(message, keyboard);
  return ctx.reply(message, keyboard);
}

bot.command('elite', async (ctx) => {
  if (!eliteAllowed(ctx)) return ctx.reply('🚫 هذه اللوحة خاصة بالإدارة.');
  return showElite(ctx, 'home', false);
});

bot.action('elite:home', async (ctx) => {
  if (!eliteAllowed(ctx)) return ctx.answerCbQuery('غير مصرح لك', { show_alert: true });
  await ctx.answerCbQuery();
  return showElite(ctx, 'home');
});

bot.action('elite:refresh', async (ctx) => {
  if (!eliteAllowed(ctx)) return ctx.answerCbQuery('غير مصرح لك', { show_alert: true });
  await ctx.answerCbQuery('تم التحديث');
  return showElite(ctx, 'home');
});

bot.action(/^elite:(stats|users|logs|instances|connected|pending|groups)$/, async (ctx) => {
  if (!eliteAllowed(ctx)) return ctx.answerCbQuery('غير مصرح لك', { show_alert: true });
  await ctx.answerCbQuery();
  return showElite(ctx, ctx.match[1]);
});

bot.action(/^elite:instance:(\d+)$/, async (ctx) => {
  if (!eliteAllowed(ctx)) return ctx.answerCbQuery('غير مصرح لك', { show_alert: true });
  await ctx.answerCbQuery();

  const id = ctx.match[1];
  const record = owners[id];
  if (!record) return ctx.editMessageText('هذه النسخة غير موجودة.', eliteBack());

  const phone = String(record.phone || '');
  const masked = phone.length > 4 ? '******' + phone.slice(-4) : 'غير معروف';

  let stats = {};
  try {
    stats = JSON.parse(fs.readFileSync(
      path.join(instancePath(id), 'data', 'elite-stats.json'), 'utf8'
    ));
  } catch {}

  const message =
    '🤖 تفاصيل النسخة\n━━━━━━━━━━━━━━━━━━\n' +
    '🆔 Telegram ID: ' + id + '\n' +
    '📱 الرقم: ' + masked + '\n' +
    '🔌 الحالة: ' + (record.status || 'غير معروفة') + '\n' +
    '⚙️ العملية: ' + (workers.has(id) ? 'نشطة' : 'غير نشطة') + '\n' +
    '📅 التنصيب: ' + (record.createdAt || 'غير معروف') + '\n' +
    '👥 المجموعات: ' + (Number(stats.groups) || 0) + '\n' +
    '🧑‍🤝‍🧑 الأعضاء: ' + (Number(stats.members) || 0) + '\n' +
    '🛡️ المشرفون: ' + (Number(stats.admins) || 0);

  return ctx.editMessageText(message, eliteBack());
});

bot.command(['install', 'تنصيب'], async (ctx) => {
    if (sessions.has(String(ctx.from.id))) return ctx.reply('لديك عملية جارية بالفعل. أرسل /cancel.');
    await ctx.reply('📱 أرسل رقم واتساب مع رمز الدولة، بدون +. مثال: 212612345678');
    sessions.set(String(ctx.from.id), { step: 'await_phone' });
  });

  bot.command(['number', 'رقم'], async (ctx) => {
    const raw = ctx.message?.text?.trim().split(/\s+/)[1];
    if (!raw) return ctx.reply('مثال: /number 212612345678');
    sessions.delete(String(ctx.from.id));
    await beginInstall(ctx, raw);
  });

  bot.command(['cancel', 'إلغاء'], async (ctx) => {
    const id = String(ctx.from.id);
    const state = sessions.get(id);
    if (!state) return ctx.reply('لا توجد عملية جارية.');
    sessions.delete(id);
    if (owners[id]) {
      await stopWorker(id);
      recordEliteEvent(id, 'removed', owners[id]);
      delete owners[id];
      saveOwners();
      removeInstanceFiles(id);
    }
    await ctx.reply('✅ تم إلغاء العملية.');
  });

  bot.command(['mybot', 'نسختي'], async (ctx) => {
    const id = String(ctx.from.id);
    const record = owners[id];
    if (!record) return ctx.reply('ليس لديك نسخة مسجلة. استعمل /install للبدء.');
    await ctx.reply(`🤖 حالة نسختك\n📱 الرقم: ${record.phone}\n🔌 الحالة: ${record.status || 'غير معروفة'}\n🖥️ لكل مستخدم مجلد وجلسة منفصلان.`);
  });

  bot.command(['remove', 'حذف_نسختي'], async (ctx) => {
    const id = String(ctx.from.id);
    if (!owners[id]) return ctx.reply('لا توجد نسخة مسجلة لحذفها.');
    sessions.delete(id);
    await stopWorker(id);
    recordEliteEvent(id, 'removed', owners[id]);
      delete owners[id];
    saveOwners();
    removeInstanceFiles(id);
    await ctx.reply('✅ تم حذف نسختك وإنهاء جلسة واتساب الخاصة بها.');
  });

  bot.on('text', async (ctx) => {
    const id = String(ctx.from.id);
    const state = sessions.get(id);
    if (!state || state.step !== 'await_phone') return;
    const raw = ctx.message.text.trim();
    if (raw.startsWith('/')) return;
    sessions.delete(id);
    await beginInstall(ctx, raw);
  });

  bot.catch((error) => console.error('❌ [Telegram]', error?.message || error));
  bot.launch({ dropPendingUpdates: true })
    .then(() => console.log('✅ [Telegram] Public installer is running'))
    .catch((error) => console.error('❌ [Telegram] Launch failed:', error?.message || error));

  // Restore every previously registered user's isolated process after restart.
  for (const [userId, record] of Object.entries(owners)) {
    if (!record?.phone) continue;
    try { startWorker(bot, userId, record, { restoring: true }); }
    catch (error) { console.error(`[Restore ${userId}]`, error?.message || error); }
  }

  const shutdown = async () => {
    bot.stop('shutdown');
    await Promise.all([...workers.keys()].map((id) => stopWorker(id)));
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
  return bot;
}

export default startTelegramInstall;
